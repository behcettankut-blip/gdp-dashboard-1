import React from 'react';
import { X } from 'lucide-react';
import { ANSWER_KEY_SUMMARY, SCORE_TIERS, Language } from '../data/quizData';
import { UI_TRANSLATIONS } from '../data/translations';

interface MethodologyModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const MethodologyModal: React.FC<MethodologyModalProps> = ({ isOpen, onClose, lang }) => {
  if (!isOpen) return null;
  const t = UI_TRANSLATIONS[lang];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/50 backdrop-blur-xs">
      <div className="bg-white border border-stone-200 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-100 pb-4 mb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
              {t.methodology.badge}
            </span>
            <h3 className="text-lg sm:text-xl font-bold text-stone-900 mt-0.5">
              {t.methodology.title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-6 text-sm text-stone-600">
          <div>
            <h4 className="font-bold text-stone-900 mb-2">
              {t.methodology.logicTitle}
            </h4>
            <p className="leading-relaxed">
              {t.methodology.logicDesc}
            </p>
          </div>

          {/* Reference Answer Key */}
          <div>
            <h4 className="font-bold text-stone-900 mb-2">
              {t.methodology.keyTitle}
            </h4>
            <div className="bg-stone-50 border border-stone-200 rounded-xl overflow-hidden text-xs">
              <div className="grid grid-cols-12 bg-stone-100 px-3 py-2 font-bold text-stone-700 border-b border-stone-200">
                <span className="col-span-2">{t.methodology.colQ}</span>
                <span className="col-span-3">{t.methodology.colKey}</span>
                <span className="col-span-7">{t.methodology.colCriterion}</span>
              </div>
              <div className="divide-y divide-stone-200/60">
                {ANSWER_KEY_SUMMARY.map((item) => (
                  <div key={item.questionId} className="grid grid-cols-12 px-3 py-2 items-center">
                    <span className="col-span-2 font-mono font-semibold text-stone-900">
                      #{item.questionId}
                    </span>
                    <span className="col-span-3 font-bold text-emerald-700">
                      {item.questionId}-{item.key}
                    </span>
                    <span className="col-span-7 text-stone-700">
                      {lang === 'tr' ? item.textTr : item.textEn}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Evaluation Tiers */}
          <div>
            <h4 className="font-bold text-stone-900 mb-2">
              {t.methodology.tierTitle}
            </h4>
            <div className="space-y-2">
              {SCORE_TIERS.map((tier) => (
                <div
                  key={tier.id}
                  className="p-3 rounded-lg border border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-stone-900 text-sm whitespace-nowrap">
                      {tier.minScore}-{tier.maxScore} {lang === 'tr' ? 'Puan' : 'Pts'}
                    </span>
                    <span className="font-bold text-xs px-2 py-0.5 rounded bg-stone-100 text-stone-800">
                      {tier.label[lang]}
                    </span>
                  </div>
                  <span className="text-xs text-stone-500">{tier.badgeLabel[lang]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 pt-4 border-t border-stone-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-stone-900 text-white text-xs font-semibold hover:bg-stone-800 transition-colors cursor-pointer"
          >
            {t.methodology.close}
          </button>
        </div>
      </div>
    </div>
  );
};
