import React from 'react';
import { Question, Language } from '../data/quizData';
import { UI_TRANSLATIONS } from '../data/translations';
import { soundFX } from '../utils/audioEffects';
import { CheckCircle2, ArrowRight } from 'lucide-react';

interface ListQuizProps {
  questions: Question[];
  answers: Record<number, 'a' | 'b'>;
  lang: Language;
  onSelectAnswer: (questionId: number, optionKey: 'a' | 'b') => void;
  onComplete: () => void;
  onSwitchMode: () => void;
}

export const ListQuiz: React.FC<ListQuizProps> = ({
  questions,
  answers,
  lang,
  onSelectAnswer,
  onComplete,
  onSwitchMode,
}) => {
  const t = UI_TRANSLATIONS[lang];
  const answeredCount = Object.keys(answers).length;
  const isAllAnswered = answeredCount === questions.length;
  const progressPercent = Math.round((answeredCount / questions.length) * 100);

  const handleSelectAnswer = (q: Question, optionKey: 'a' | 'b') => {
    soundFX.playNavClick();
    onSelectAnswer(q.id, optionKey);
  };

  const handleComplete = () => {
    soundFX.playSuccess();
    onComplete();
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Control bar */}
      <div className="bg-white border border-stone-200 rounded-xl p-4 sm:p-5 mb-6 sticky top-20 z-20 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-stone-500 mb-1">
              <span>{t.quiz.allQuestionsTitle}</span>
              <span aria-hidden="true">·</span>
              <span className="text-stone-900 font-bold tabular-nums">
                {answeredCount} / {questions.length} ({t.quiz.completedPct.replace('{pct}', String(progressPercent))})
              </span>
            </div>
            <div className="h-2 w-48 max-w-full bg-stone-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-stone-900 rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onSwitchMode}
              className="text-xs font-medium text-stone-600 hover:text-stone-900 underline underline-offset-4 cursor-pointer"
            >
              {t.quiz.switchToStep}
            </button>

            <button
              onClick={handleComplete}
              disabled={!isAllAnswered}
              className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                isAllAnswered
                  ? 'bg-stone-900 text-white hover:bg-stone-800 shadow-xs'
                  : 'bg-stone-100 text-stone-400 cursor-not-allowed border border-stone-200'
              }`}
            >
              <span>
                {isAllAnswered
                  ? t.nav.result
                  : `${questions.length - answeredCount} ${lang === 'tr' ? 'Soru Kaldı' : 'Left'}`}
              </span>
              {isAllAnswered ? <CheckCircle2 className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Questions list */}
      <div className="space-y-6 mb-8">
        {questions.map((q) => {
          const selectedAnswer = answers[q.id];

          return (
            <div
              key={q.id}
              className={`bg-white border rounded-2xl p-5 sm:p-7 transition-all ${
                selectedAnswer
                  ? 'border-stone-200'
                  : 'border-stone-300 ring-1 ring-stone-200/50'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                  {q.id}. {q.category[lang]}
                </span>

                <div className="flex items-center gap-2">
                  {selectedAnswer ? (
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                      {t.quiz.answeredBadge}
                    </span>
                  ) : (
                    <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                      {t.quiz.waitingBadge}
                    </span>
                  )}
                </div>
              </div>

              <h3 className="text-lg sm:text-xl font-bold text-stone-900 mb-4 text-balance">
                {q.question[lang]}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {q.options.map((opt) => {
                  const isSelected = selectedAnswer === opt.key;
                  return (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() => handleSelectAnswer(q, opt.key)}
                      className={`text-left p-4 rounded-xl border-2 transition-all flex items-start gap-3 cursor-pointer ${
                        isSelected
                          ? 'border-stone-900 bg-stone-50 shadow-xs'
                          : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50/50 bg-white'
                      }`}
                    >
                      <span
                        className={`w-6 h-6 rounded-md flex items-center justify-center font-bold text-xs uppercase shrink-0 transition-colors ${
                          isSelected
                            ? 'bg-stone-900 text-white'
                            : 'bg-stone-100 text-stone-600'
                        }`}
                      >
                        {opt.key}
                      </span>
                      <span className="text-sm font-semibold text-stone-900 leading-snug">
                        {opt.label[lang]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Submit Action */}
      <div className="text-center pt-2 pb-8">
        <button
          onClick={handleComplete}
          disabled={!isAllAnswered}
          className={`inline-flex items-center gap-2 px-8 py-3.5 rounded-xl text-base font-bold transition-all shadow-sm cursor-pointer ${
            isAllAnswered
              ? 'bg-stone-900 text-white hover:bg-stone-800'
              : 'bg-stone-200 text-stone-400 cursor-not-allowed'
          }`}
        >
          <span>
            {isAllAnswered
              ? t.quiz.finish
              : t.quiz.finishBanner.replace(
                  '{count}',
                  String(questions.length - answeredCount)
                )}
          </span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
