import React from 'react';
import { Language } from '../data/quizData';
import { UI_TRANSLATIONS } from '../data/translations';

interface FooterProps {
  onNavigate: (section: 'quiz' | 'scoring' | 'dimensions') => void;
  onOpenMethodology: () => void;
  onOpenHygge?: () => void;
  lang: Language;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenMethodology, onOpenHygge, lang }) => {
  const t = UI_TRANSLATIONS[lang];

  return (
    <footer className="border-t border-stone-200 bg-white no-print mt-auto py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
        <div>
          <span className="text-stone-600 font-medium">{t.footer.disclaimer}</span>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <button
            onClick={() => onNavigate('quiz')}
            className="hover:text-stone-900 transition-colors cursor-pointer"
          >
            {t.nav.quiz}
          </button>
          <button
            onClick={onOpenMethodology}
            className="hover:text-stone-900 transition-colors cursor-pointer"
          >
            {t.nav.methodology}
          </button>
          <button
            onClick={() => onNavigate('dimensions')}
            className="hover:text-stone-900 transition-colors cursor-pointer"
          >
            {t.nav.dimensions}
          </button>
          {onOpenHygge && (
            <button
              onClick={onOpenHygge}
              className="text-amber-800 hover:text-amber-950 font-semibold transition-colors cursor-pointer flex items-center gap-1"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
              <span>{t.nav.hygge}</span>
            </button>
          )}
        </div>
      </div>
    </footer>
  );
};
