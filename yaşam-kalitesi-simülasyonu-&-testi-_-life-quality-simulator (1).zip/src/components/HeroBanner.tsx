import React, { useState } from 'react';
import { ArrowRight, ListFilter, Sliders, Volume2 } from 'lucide-react';
import { Language } from '../data/quizData';
import { UI_TRANSLATIONS } from '../data/translations';
import { AudioSpeakerButton } from './AudioSpeakerButton';

interface HeroBannerProps {
  onStartQuiz: (mode: 'step' | 'list') => void;
  answeredCount: number;
  lang: Language;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  onStartQuiz,
  answeredCount,
  lang,
}) => {
  const [imgError, setImgError] = useState(false);
  const t = UI_TRANSLATIONS[lang];

  const heroSpeech = `${t.hero.title}. ${t.hero.subtitle}`;

  return (
    <div className="relative overflow-hidden bg-white border-2 border-stone-800 rounded-2xl sm:rounded-3xl p-6 sm:p-10 mb-8 shadow-xl ring-1 ring-stone-900/10">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Content column */}
        <div className="lg:col-span-7 flex flex-col justify-center">
          {/* Metadata chips & Voice button */}
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-stone-500">
              {t.hero.metaTags.map((tag, idx) => (
                <React.Fragment key={tag}>
                  <span>{tag}</span>
                  {idx < t.hero.metaTags.length - 1 && (
                    <span aria-hidden="true" className="text-stone-300">
                      ·
                    </span>
                  )}
                </React.Fragment>
              ))}
            </div>

            <AudioSpeakerButton
              textToSpeak={heroSpeech}
              lang={lang}
              size="sm"
              variant="ghost"
              label={lang === 'tr' ? 'Tanıtımı Dinle' : 'Listen Intro'}
            />
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-stone-900 leading-tight mb-4 text-balance">
            {t.hero.title}
          </h1>

          <p className="text-stone-600 text-sm sm:text-base leading-relaxed mb-6 max-w-xl">
            {t.hero.subtitle}
          </p>

          {/* 3 Core Highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 pb-6 border-t border-stone-100 text-xs text-stone-600">
            <div>
              <span className="font-bold text-stone-900 block mb-0.5">
                {t.hero.feature1Title}
              </span>
              {t.hero.feature1Desc}
            </div>
            <div>
              <span className="font-bold text-stone-900 block mb-0.5">
                {t.hero.feature2Title}
              </span>
              {t.hero.feature2Desc}
            </div>
            <div>
              <span className="font-bold text-stone-900 block mb-0.5">
                {t.hero.feature3Title}
              </span>
              {t.hero.feature3Desc}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onStartQuiz('step')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-stone-900 text-white text-sm font-bold hover:bg-stone-800 transition-colors shadow-md cursor-pointer"
            >
              <span>{answeredCount > 0 ? t.hero.continueTest : t.hero.startStep}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onStartQuiz('list')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-stone-300 bg-white text-stone-800 text-sm font-semibold hover:bg-stone-100 transition-colors cursor-pointer shadow-xs"
            >
              <ListFilter className="w-4 h-4 text-stone-600" />
              <span>{t.hero.startList}</span>
            </button>
          </div>
        </div>

        {/* Visual column */}
        <div className="lg:col-span-5">
          <div className="relative aspect-4/3 sm:aspect-16/10 lg:aspect-4/3 rounded-xl overflow-hidden bg-stone-100 border border-stone-300">
            {!imgError ? (
              <img
                src="/src/assets/images/hero_life_balance_1790788422695.jpg"
                alt="Yaşam kalitesi ve içsel denge"
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-stone-50 to-stone-200 text-stone-600">
                <span className="text-sm font-semibold">{t.appTitle}</span>
              </div>
            )}

            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-stone-950/75 via-stone-950/30 to-transparent p-4 text-white">
              <p className="text-xs font-medium text-stone-100 italic">
                {t.hero.heroQuote}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
