import React, { useEffect, useCallback } from 'react';
import { Question, Language } from '../data/quizData';
import { UI_TRANSLATIONS } from '../data/translations';
import { soundFX } from '../utils/audioEffects';
import { ChevronLeft, ChevronRight, CheckCircle2, ArrowRight } from 'lucide-react';

interface StepQuizProps {
  questions: Question[];
  currentIndex: number;
  answers: Record<number, 'a' | 'b'>;
  lang: Language;
  onSelectAnswer: (questionId: number, optionKey: 'a' | 'b') => void;
  onPrev: () => void;
  onNext: () => void;
  onJumpTo: (index: number) => void;
  onComplete: () => void;
  onSwitchMode: () => void;
}

export const StepQuiz: React.FC<StepQuizProps> = ({
  questions,
  currentIndex,
  answers,
  lang,
  onSelectAnswer,
  onPrev,
  onNext,
  onJumpTo,
  onComplete,
  onSwitchMode,
}) => {
  const t = UI_TRANSLATIONS[lang];
  const currentQuestion = questions[currentIndex];
  const currentAnswer = answers[currentQuestion.id];
  const answeredCount = Object.keys(answers).length;
  const isAllAnswered = answeredCount === questions.length;
  const isLastQuestion = currentIndex === questions.length - 1;

  // Play standard click sound like other buttons when selecting an option
  const handleSelectAnswer = (optionKey: 'a' | 'b') => {
    soundFX.playNavClick();
    onSelectAnswer(currentQuestion.id, optionKey);
  };

  const handleNext = () => {
    soundFX.playNavClick();
    onNext();
  };

  const handlePrev = () => {
    soundFX.playNavClick();
    onPrev();
  };

  const handleJump = (idx: number) => {
    soundFX.playNavClick();
    onJumpTo(idx);
  };

  const handleComplete = () => {
    soundFX.playSuccess();
    onComplete();
  };

  // Keyboard shortcut listener
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      if (e.key === 'a' || e.key === 'A' || e.key === '1') {
        handleSelectAnswer('a');
      } else if (e.key === 'b' || e.key === 'B' || e.key === '2') {
        handleSelectAnswer('b');
      } else if (e.key === 'ArrowRight' && currentIndex < questions.length - 1) {
        handleNext();
      } else if (e.key === 'ArrowLeft' && currentIndex > 0) {
        handlePrev();
      } else if (e.key === 'Enter' && isAllAnswered) {
        handleComplete();
      }
    },
    [currentQuestion, currentIndex, questions, isAllAnswered]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const progressPercent = Math.round((answeredCount / questions.length) * 100);

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Top Header Controls */}
      <div className="flex items-center justify-between gap-4 mb-4">
        <div className="flex items-center gap-2 text-xs font-semibold text-stone-500">
          <span className="text-stone-900 font-bold tabular-nums">
            {t.quiz.questionIndex
              .replace('{current}', String(currentIndex + 1))
              .replace('{total}', String(questions.length))}
          </span>
          <span aria-hidden="true">·</span>
          <span>{currentQuestion.category[lang]}</span>
          <span aria-hidden="true">·</span>
          <span className="tabular-nums font-mono">
            {t.quiz.completedPct.replace('{pct}', String(progressPercent))}
          </span>
        </div>

        <button
          onClick={onSwitchMode}
          className="text-xs font-medium text-stone-600 hover:text-stone-900 underline underline-offset-4 cursor-pointer"
        >
          {t.quiz.switchToList}
        </button>
      </div>

      {/* Progress Bar */}
      <div className="h-1.5 w-full bg-stone-200 rounded-full overflow-hidden mb-6">
        <div
          className="h-full bg-stone-900 transition-all duration-300 rounded-full"
          style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
        />
      </div>

      {/* Main Question Card */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-10 shadow-xs mb-6">
        <div className="flex items-center justify-between gap-3 mb-2">
          <span className="text-xs uppercase tracking-wider text-stone-500 font-semibold">
            {currentQuestion.domainName[lang]}
          </span>
        </div>

        <h2 className="text-xl sm:text-2xl font-bold text-stone-900 mb-6 text-balance">
          {currentQuestion.id}. {currentQuestion.question[lang]}
        </h2>

        {/* Options */}
        <div className="space-y-3">
          {currentQuestion.options.map((opt) => {
            const isSelected = currentAnswer === opt.key;
            return (
              <button
                key={opt.key}
                type="button"
                onClick={() => handleSelectAnswer(opt.key)}
                className={`w-full text-left p-4 sm:p-5 rounded-xl border-2 transition-all flex items-start justify-between gap-4 cursor-pointer group ${
                  isSelected
                    ? 'border-stone-900 bg-stone-50/80 shadow-xs'
                    : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50/40 bg-white'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div
                    className={`shrink-0 w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs uppercase transition-colors ${
                      isSelected
                        ? 'bg-stone-900 text-white'
                        : 'bg-stone-100 text-stone-600 group-hover:bg-stone-200'
                    }`}
                  >
                    {opt.key}
                  </div>
                  <div>
                    <span className="text-base sm:text-lg font-medium text-stone-900 block">
                      {opt.label[lang]}
                    </span>
                  </div>
                </div>

                <div className="shrink-0 pt-0.5">
                  <div
                    className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                      isSelected
                        ? 'border-stone-900 bg-stone-900 text-white'
                        : 'border-stone-300 bg-white'
                    }`}
                  >
                    {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Significance */}
        <div className="mt-6 pt-5 border-t border-stone-100 flex flex-wrap items-center justify-between text-xs text-stone-500 gap-2">
          <span>{currentQuestion.significance[lang]}</span>
          <span className="hidden sm:inline-block font-mono text-[11px] text-stone-400">
            {t.quiz.keyboardHint}
          </span>
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between gap-3 mb-6">
        <button
          type="button"
          onClick={handlePrev}
          disabled={currentIndex === 0}
          className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-sm font-medium border border-stone-200 bg-white transition-colors cursor-pointer ${
            currentIndex === 0
              ? 'opacity-40 cursor-not-allowed text-stone-400'
              : 'text-stone-700 hover:bg-stone-50'
          }`}
        >
          <ChevronLeft className="w-4 h-4" />
          <span>{t.quiz.prev}</span>
        </button>

        {isLastQuestion ? (
          <button
            type="button"
            onClick={handleComplete}
            disabled={!isAllAnswered}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer shadow-xs ${
              isAllAnswered
                ? 'bg-stone-900 text-white hover:bg-stone-800'
                : 'bg-stone-200 text-stone-500 cursor-not-allowed'
            }`}
          >
            <span>{t.quiz.finish}</span>
            <CheckCircle2 className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={handleNext}
            className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-lg text-sm font-semibold bg-stone-900 text-white hover:bg-stone-800 transition-colors cursor-pointer shadow-xs"
          >
            <span>{t.quiz.next}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Question Quick-Jump Dots */}
      <div className="bg-white border border-stone-200 rounded-xl p-3 flex items-center justify-between gap-1 overflow-x-auto">
        <span className="text-xs text-stone-500 font-medium px-2 whitespace-nowrap hidden sm:inline">
          {lang === 'tr' ? 'Sorular:' : 'Questions:'}
        </span>
        <div className="flex items-center gap-1.5 w-full justify-between sm:justify-start">
          {questions.map((q, idx) => {
            const hasAnswer = answers[q.id] !== undefined;
            const isCurrent = idx === currentIndex;
            return (
              <button
                key={q.id}
                onClick={() => handleJump(idx)}
                title={`${q.id}. ${q.category[lang]}`}
                className={`w-8 h-8 rounded-lg text-xs font-semibold flex items-center justify-center transition-all cursor-pointer ${
                  isCurrent
                    ? 'ring-2 ring-stone-900 font-bold bg-stone-900 text-white'
                    : hasAnswer
                    ? 'bg-stone-100 text-stone-900 hover:bg-stone-200'
                    : 'bg-stone-50 text-stone-400 hover:bg-stone-100 border border-dashed border-stone-200'
                }`}
              >
                {q.id}
              </button>
            );
          })}
        </div>

        {isAllAnswered && !isLastQuestion && (
          <button
            onClick={handleComplete}
            className="hidden sm:inline-flex items-center gap-1 text-xs font-semibold text-stone-900 bg-stone-100 hover:bg-stone-200 px-3 py-1.5 rounded-md cursor-pointer whitespace-nowrap shrink-0 ml-2"
          >
            <span>{t.quiz.finish}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
