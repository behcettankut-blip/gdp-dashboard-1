import React from 'react';
import { RotateCcw, X, AlertTriangle } from 'lucide-react';
import { Language } from '../data/quizData';

interface ResetConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  lang: Language;
}

export const ResetConfirmModal: React.FC<ResetConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  lang,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white border border-stone-200 rounded-2xl max-w-md w-full shadow-2xl p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700 mb-4">
          <RotateCcw className="w-6 h-6 animate-spin-reverse" />
        </div>

        <h3 className="text-lg font-bold text-stone-900 mb-2">
          {lang === 'tr' ? 'Testi Yeniden Başlat?' : 'Restart Assessment?'}
        </h3>

        <p className="text-sm text-stone-600 mb-6 leading-relaxed">
          {lang === 'tr'
            ? 'Mevcut işaretlediğiniz tüm yanıtlar ve puanınız sıfırlanacaktır. Teste en baştan başlamak istediğinize emin misiniz?'
            : 'All current selections and scores will be cleared. Are you sure you want to restart from question 1?'}
        </p>

        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors cursor-pointer"
          >
            {lang === 'tr' ? 'Vazgeç' : 'Cancel'}
          </button>

          <button
            type="button"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="px-4 py-2 text-xs sm:text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors cursor-pointer shadow-sm flex items-center gap-1.5"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{lang === 'tr' ? 'Evet, Yeniden Başlat' : 'Yes, Restart'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
