import React, { useState } from 'react';
import {
  Question,
  Language,
  calculateScore,
  getScoreTier,
  SIMULATION_PRESETS,
} from '../data/quizData';
import { UI_TRANSLATIONS } from '../data/translations';
import { ScoreGauge } from './ScoreGauge';
import { AudioSpeakerButton } from './AudioSpeakerButton';
import { soundFX } from '../utils/audioEffects';
import { speechManager } from '../utils/speech';
import {
  Sliders,
  Sparkles,
  TrendingUp,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Zap,
  Info,
} from 'lucide-react';

interface SimulationViewProps {
  questions: Question[];
  originalAnswers: Record<number, 'a' | 'b'>;
  lang: Language;
  onApplyToTest: (simulatedAnswers: Record<number, 'a' | 'b'>) => void;
  onGoToTest: () => void;
}

export const SimulationView: React.FC<SimulationViewProps> = ({
  questions,
  originalAnswers,
  lang,
  onApplyToTest,
  onGoToTest,
}) => {
  const t = UI_TRANSLATIONS[lang];

  // Initialize simulation with original answers if any, or default preset
  const [simAnswers, setSimAnswers] = useState<Record<number, 'a' | 'b'>>(() => {
    if (Object.keys(originalAnswers).length === 10) {
      return { ...originalAnswers };
    }
    // Default balanced preset
    return {
      1: 'a', 2: 'b', 3: 'b', 4: 'b', 5: 'a',
      6: 'b', 7: 'a', 8: 'a', 9: 'a', 10: 'b',
    };
  });

  const [activePreset, setActivePreset] = useState<string | null>(null);

  const simScore = calculateScore(simAnswers);
  const simTier = getScoreTier(simScore);

  const origScore = Object.keys(originalAnswers).length > 0 ? calculateScore(originalAnswers) : null;
  const scoreDiff = origScore !== null ? simScore - origScore : 0;

  const handleToggle = (q: Question) => {
    setActivePreset(null);
    const current = simAnswers[q.id];
    const isPositive = current === q.positiveAnswer;
    const alternative = q.options.find((o) => o.key !== q.positiveAnswer)?.key || 'b';
    const nextAnswer = isPositive ? alternative : q.positiveAnswer;
    const nextPositive = nextAnswer === q.positiveAnswer;

    soundFX.playToggle(nextPositive);

    const updated = {
      ...simAnswers,
      [q.id]: nextAnswer,
    };
    const newScore = calculateScore(updated);

    const speakText =
      lang === 'tr'
        ? `${q.category.tr}: ${nextPositive ? 'Olumlu yapıldı (+1 Puan)' : 'Eksik yapıldı'}. Simülasyon puanı: ${newScore}`
        : `${q.category.en}: ${nextPositive ? 'Criterion met (+1 Pts)' : 'Unmet'}. Simulated score: ${newScore}`;
    speechManager.speak(speakText, { lang, rate: 1.15 });

    setSimAnswers(updated);
  };

  const handleLoadPreset = (presetId: string) => {
    const preset = SIMULATION_PRESETS.find((p) => p.id === presetId);
    if (preset) {
      soundFX.playNavClick();
      setSimAnswers({ ...preset.values });
      setActivePreset(preset.id);
      const newScore = calculateScore(preset.values);
      const presetSpeech =
        lang === 'tr'
          ? `Senaryo yüklendi: ${preset.name.tr}. Simüle puan: ${newScore}`
          : `Scenario loaded: ${preset.name.en}. Simulated score: ${newScore}`;
      speechManager.speak(presetSpeech, { lang, rate: 1.1 });
    }
  };

  const handleLoadOriginal = () => {
    if (Object.keys(originalAnswers).length > 0) {
      soundFX.playNavClick();
      setSimAnswers({ ...originalAnswers });
      setActivePreset('my_test');
      speechManager.speak(
        lang === 'tr' ? 'Orijinal test sonuçlarınız yüklendi.' : 'Original test results loaded.',
        { lang }
      );
    }
  };

  const handleResetToOptimal = () => {
    handleLoadPreset('ideal_balance');
  };

  // Build narration text for the simulation
  const narrationSummary =
    lang === 'tr'
      ? `Yaşam Kalitesi Simülasyonu sonucu: 10 üzerinden ${simScore} puan ile ${simTier.label.tr} seviyesindesiniz. ${
          simScore >= 8
            ? 'Tüm yaşam alanlarında mükemmel bir denge kurulmuş görünüyor.'
            : simScore >= 6
            ? 'Dengeli ve olumlu bir yaşam standardı. Birkaç eksik alanı tamamlayarak zirveye çıkabilirsiniz.'
            : 'Belirgin eksiklikler yaşam kalitesini baskılıyor. Sağlık, gelir ve iş ortamındaki iyileştirmeler en hızlı dönüşümü sağlayacaktır.'
        }`
      : `Life Quality Simulation result: Your simulated score is ${simScore} out of 10, placing you in the ${simTier.label.en} tier. ${
          simScore >= 8
            ? 'Optimal balance achieved across all primary life dimensions.'
            : simScore >= 6
            ? 'Solid and steady baseline. Fine-tuning the remaining weak points will unlock peak vitality.'
            : 'Significant deficits are dampening your well-being. Focusing on health, career, and finance provides the fastest ROI.'
        }`;

  return (
    <div className="w-full max-w-5xl mx-auto space-y-8 pb-16">
      {/* Top Banner / Header */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-10 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-stone-900 text-white">
              <Sliders className="w-3.5 h-3.5" />
              <span>{t.simulation.badge}</span>
            </span>
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              {t.badgeFree}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <AudioSpeakerButton
              textToSpeak={narrationSummary}
              lang={lang}
              label={t.simulation.audioSimSummary}
              size="md"
              variant="secondary"
            />
          </div>
        </div>

        <h2 className="text-2xl sm:text-3xl font-bold text-stone-900 tracking-tight mb-3">
          {t.simulation.title}
        </h2>
        <p className="text-stone-600 text-sm sm:text-base leading-relaxed max-w-3xl mb-6">
          {t.simulation.subtitle}
        </p>

        {/* Preset Selector Bar */}
        <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-stone-500 whitespace-nowrap">
              {t.simulation.presetLabel}
            </span>
            {SIMULATION_PRESETS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleLoadPreset(preset.id)}
                className={`text-xs font-medium px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
                  activePreset === preset.id
                    ? 'bg-stone-900 text-white border-stone-900 shadow-xs'
                    : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-100 hover:text-stone-900'
                }`}
              >
                {preset.name[lang]}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {origScore !== null && (
              <button
                onClick={handleLoadOriginal}
                className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-stone-200 hover:bg-stone-300 text-stone-800 transition-colors cursor-pointer"
              >
                {t.simulation.loadCurrentAnswers}
              </button>
            )}
            <button
              onClick={handleResetToOptimal}
              className="text-xs font-medium px-2.5 py-1.5 rounded-lg text-stone-500 hover:text-stone-900 hover:bg-stone-200/50 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t.simulation.resetSim}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Dynamic Results Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Score & Gauge Column */}
        <div className="lg:col-span-7 bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-stone-400">
                {t.simulation.currentSimScore}
              </span>
              {origScore !== null && (
                <div
                  className={`inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full ${
                    scoreDiff > 0
                      ? 'bg-emerald-100 text-emerald-800'
                      : scoreDiff < 0
                      ? 'bg-rose-100 text-rose-800'
                      : 'bg-stone-100 text-stone-700'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>
                    {scoreDiff > 0 ? `+${scoreDiff}` : scoreDiff}{' '}
                    {lang === 'tr' ? 'Puan Fark' : 'Pts Delta'}
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-baseline gap-3 mb-3">
              <span className="text-5xl sm:text-6xl font-black text-stone-900 tabular-nums">
                {simScore}
              </span>
              <span className="text-2xl font-bold text-stone-400">/ 10</span>
              <span
                className={`ml-2 px-3 py-1 rounded-full text-xs font-extrabold uppercase ${
                  simTier.tone === 'rose'
                    ? 'bg-rose-100 text-rose-800'
                    : simTier.tone === 'amber'
                    ? 'bg-amber-100 text-amber-800'
                    : simTier.tone === 'teal'
                    ? 'bg-teal-100 text-teal-800'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {simTier.label[lang]}
              </span>
            </div>

            <p className="text-sm text-stone-600 mb-6">
              {simTier.description[lang]}
            </p>
          </div>

          <div className="pt-4 border-t border-stone-100">
            <ScoreGauge score={simScore} currentTier={simTier} lang={lang} />
          </div>
        </div>

        {/* Insights / What-If ROI Column */}
        <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4 text-amber-600" />
              <h3 className="text-base font-bold text-stone-900">
                {t.simulation.whatIfInsights}
              </h3>
            </div>
            <p className="text-xs text-stone-500 mb-4">
              {t.simulation.tip}
            </p>

            <div className="space-y-3">
              {questions
                .filter((q) => simAnswers[q.id] !== q.positiveAnswer)
                .slice(0, 3)
                .map((q) => (
                  <div
                    key={q.id}
                    onClick={() => handleToggle(q)}
                    className="p-3 rounded-xl border border-dashed border-stone-300 hover:border-stone-900 bg-stone-50/50 hover:bg-stone-50 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between text-xs font-semibold mb-1">
                      <span className="text-stone-800 group-hover:text-stone-900">
                        {q.category[lang]}
                      </span>
                      <span className="text-emerald-700 font-bold">
                        +{1} Puan Kazandırır
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-500 line-clamp-1">
                      {q.recommendation.advice[lang]}
                    </p>
                  </div>
                ))}

              {simScore === 10 && (
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs">
                  <span className="font-bold block mb-1">
                    {lang === 'tr' ? 'Tüm Kriterler Zirvede!' : 'All Dimensions Maxed!'}
                  </span>
                  <span>
                    {lang === 'tr'
                      ? 'Simülasyonda 10/10 puana ulaştınız. Bu senaryo fiziksel, duygusal ve maddi refahın kusursuz sinerjisini temsil eder.'
                      : 'You reached 10/10 in simulation. This condition represents optimal harmony across health, finance, and purpose.'}
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-stone-100 flex items-center justify-between gap-2">
            <button
              onClick={() => onApplyToTest(simAnswers)}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-stone-900 text-white text-xs font-bold hover:bg-stone-800 transition-colors cursor-pointer shadow-xs"
            >
              <span>
                {lang === 'tr'
                  ? 'Bu Senaryoyu Test Sonucuma Aktar'
                  : 'Apply Scenario to My Test'}
              </span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 10 Dimension Interactive Toggles Card */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-6">
          <div>
            <h3 className="text-lg font-bold text-stone-900">
              {t.simulation.dimensionSliders}
            </h3>
            <p className="text-xs text-stone-500">
              {lang === 'tr'
                ? 'Aşağıdaki 10 kriteri açıp kapatarak simülasyon puanınızı anlık olarak değiştirin.'
                : 'Toggle each of the 10 criteria on or off to adjust the live simulated score.'}
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-medium text-stone-500">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>{lang === 'tr' ? 'Sağlandı (+1)' : 'Met (+1)'}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-stone-300" />
              <span>{lang === 'tr' ? 'Eksik (0)' : 'Unmet (0)'}</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {questions.map((q) => {
            const isPositive = simAnswers[q.id] === q.positiveAnswer;
            return (
              <div
                key={q.id}
                onClick={() => handleToggle(q)}
                className={`p-4 rounded-xl border-2 transition-all cursor-pointer flex items-center justify-between gap-4 ${
                  isPositive
                    ? 'border-stone-900 bg-stone-50/70 shadow-xs'
                    : 'border-stone-200 bg-white hover:border-stone-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                      isPositive
                        ? 'bg-stone-900 text-white'
                        : 'bg-stone-100 text-stone-400'
                    }`}
                  >
                    #{q.id}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-stone-500 uppercase tracking-wider block">
                      {q.category[lang]}
                    </span>
                    <span className="text-sm font-semibold text-stone-900 block leading-snug">
                      {q.question[lang]}
                    </span>
                    <span
                      className={`text-[11px] font-medium block mt-1 ${
                        isPositive ? 'text-emerald-700' : 'text-stone-400'
                      }`}
                    >
                      {isPositive
                        ? `✓ ${q.positiveLabel[lang]}`
                        : `✕ ${
                            q.options.find((o) => o.key !== q.positiveAnswer)?.label[lang] ||
                            'Eksik Kriter'
                          }`}
                    </span>
                  </div>
                </div>

                {/* Switch toggle control */}
                <div className="shrink-0">
                  <div
                    className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                      isPositive ? 'bg-stone-900' : 'bg-stone-200'
                    }`}
                  >
                    <div
                      className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                        isPositive ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
