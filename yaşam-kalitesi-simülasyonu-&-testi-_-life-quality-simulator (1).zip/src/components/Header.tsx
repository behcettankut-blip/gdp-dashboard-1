import React from 'react';
import { Language } from '../data/quizData';
import { UI_TRANSLATIONS } from '../data/translations';
import { Languages, RotateCcw, Volume2, VolumeX, Sparkles, BookOpen } from 'lucide-react';

interface HeaderProps {
  onNavigate: (section: 'quiz' | 'scoring' | 'dimensions') => void;
  onOpenHygge: () => void;
  activeSection: string;
  onReset: () => void;
  isCompleted: boolean;
  answeredCount: number;
  lang: Language;
  onToggleLang: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onNavigate,
  onOpenHygge,
  activeSection,
  onReset,
  isCompleted,
  answeredCount,
  lang,
  onToggleLang,
  soundEnabled,
  onToggleSound,
}) => {
  const t = UI_TRANSLATIONS[lang];
  const showResetButton = answeredCount > 0 || isCompleted;

  return (
    <header className="sticky top-0 z-30 bg-stone-50/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
        {/* Brand title */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('quiz')}
            className="text-left font-extrabold text-base sm:text-lg lg:text-xl tracking-tight text-stone-900 hover:text-stone-700 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
          >
            <span>{t.appTitle}</span>
          </button>
        </div>

        {/* Navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs sm:text-sm font-semibold text-stone-600">
          <button
            onClick={() => onNavigate('quiz')}
            className={`transition-colors whitespace-nowrap cursor-pointer hover:text-stone-900 ${
              activeSection === 'quiz' ? 'text-stone-950 font-bold border-b-2 border-stone-900 pb-0.5' : ''
            }`}
          >
            {isCompleted ? t.nav.result : t.nav.quiz}
          </button>

          <button
            onClick={() => onNavigate('scoring')}
            className={`transition-colors whitespace-nowrap cursor-pointer hover:text-stone-900 ${
              activeSection === 'scoring' ? 'text-stone-950 font-bold border-b-2 border-stone-900 pb-0.5' : ''
            }`}
          >
            {t.nav.methodology}
          </button>

          <button
            onClick={() => onNavigate('dimensions')}
            className={`transition-colors whitespace-nowrap cursor-pointer hover:text-stone-900 ${
              activeSection === 'dimensions' ? 'text-stone-950 font-bold border-b-2 border-stone-900 pb-0.5' : ''
            }`}
          >
            {t.nav.dimensions}
          </button>

          <button
            onClick={onOpenHygge}
            className="transition-all whitespace-nowrap cursor-pointer text-stone-700 hover:text-amber-900 hover:bg-amber-50/80 px-2.5 py-1 rounded-md border border-amber-200/50 flex items-center gap-1.5"
            title={t.nav.hygge}
          >
            <span className="w-2 h-2 rounded-full bg-amber-500 shadow-2xs" />
            <span className="font-semibold">{t.nav.hygge}</span>
          </button>
        </nav>

        {/* Right side tools */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Audio toggle button with instant stop capability */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? t.audio.soundOn : t.audio.soundOff}
            className={`px-2.5 py-1.5 rounded-lg border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              soundEnabled
                ? 'border-emerald-300 bg-emerald-50 text-emerald-900 hover:bg-emerald-100 shadow-xs'
                : 'border-stone-300 bg-stone-100 text-stone-500 hover:bg-stone-200'
            }`}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-700 animate-pulse" />
            ) : (
              <VolumeX className="w-4 h-4 text-stone-500" />
            )}
            <span className="text-xs">
              {soundEnabled ? (lang === 'tr' ? 'Ses Açık' : 'Sound ON') : (lang === 'tr' ? 'Ses Kapalı' : 'Muted')}
            </span>
          </button>

          {/* Bilingual Switcher (TR / EN) */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-300 bg-white hover:bg-stone-100 text-xs font-bold text-stone-800 transition-colors cursor-pointer shadow-xs"
            title="Dili Değiştir / Change Language"
          >
            <Languages className="w-3.5 h-3.5 text-stone-600" />
            <span className="uppercase">{lang === 'tr' ? 'EN' : 'TR'}</span>
          </button>

          {/* Reset button - always accessible whenever user has started or completed */}
          {showResetButton ? (
            <button
              onClick={onReset}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-xs"
              title={lang === 'tr' ? 'Tüm cevapları sıfırla ve yeniden başla' : 'Reset all answers and restart'}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t.nav.reset}</span>
            </button>
          ) : (
            <button
              onClick={() => onNavigate('quiz')}
              className="hidden sm:inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors cursor-pointer"
            >
              <span>{t.nav.startTest}</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile nav bar */}
      <div className="md:hidden flex items-center justify-around px-3 py-2 border-t border-stone-200 bg-stone-100/60 text-xs font-semibold text-stone-600 overflow-x-auto gap-2">
        <button
          onClick={() => onNavigate('quiz')}
          className={`px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeSection === 'quiz' ? 'bg-stone-900 text-white' : 'hover:text-stone-900'
          }`}
        >
          {isCompleted ? t.nav.result : t.nav.quiz}
        </button>
        <button
          onClick={() => onNavigate('scoring')}
          className="px-2 py-1 rounded hover:text-stone-900 transition-colors whitespace-nowrap"
        >
          {t.nav.methodology}
        </button>
        <button
          onClick={() => onNavigate('dimensions')}
          className={`px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeSection === 'dimensions' ? 'bg-stone-900 text-white' : 'hover:text-stone-900'
          }`}
        >
          {t.nav.dimensions}
        </button>
        <button
          onClick={onOpenHygge}
          className="px-2 py-1 rounded text-amber-900 bg-amber-100/80 border border-amber-300/80 transition-colors whitespace-nowrap flex items-center gap-1"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
          <span>{t.nav.hygge}</span>
        </button>
      </div>
    </header>
  );
};
