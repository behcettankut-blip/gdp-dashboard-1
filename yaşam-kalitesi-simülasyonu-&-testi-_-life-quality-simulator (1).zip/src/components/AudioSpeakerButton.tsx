import React, { useEffect, useState } from 'react';
import { Volume2, VolumeX, Loader2 } from 'lucide-react';
import { speechManager } from '../utils/speech';
import { Language } from '../data/quizData';

interface AudioSpeakerButtonProps {
  textToSpeak: string;
  lang: Language;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'primary' | 'secondary' | 'ghost';
  className?: string;
}

export const AudioSpeakerButton: React.FC<AudioSpeakerButtonProps> = ({
  textToSpeak,
  lang,
  label,
  size = 'md',
  variant = 'secondary',
  className = '',
}) => {
  const [isSpeakingThis, setIsSpeakingThis] = useState(false);
  const [isSupported, setIsSupported] = useState(true);

  useEffect(() => {
    setIsSupported(speechManager.isSupported());

    const unsubscribe = speechManager.subscribe((speaking, spokenText) => {
      // If speaking and spoken text matches this button's text
      if (speaking && spokenText === textToSpeak) {
        setIsSpeakingThis(true);
      } else {
        setIsSpeakingThis(false);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [textToSpeak]);

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isSupported) return;

    if (isSpeakingThis) {
      speechManager.stop();
    } else {
      speechManager.speak(textToSpeak, {
        lang,
        onStart: () => setIsSpeakingThis(true),
        onEnd: () => setIsSpeakingThis(false),
        onError: () => setIsSpeakingThis(false),
      });
    }
  };

  if (!isSupported) return null;

  const sizeClasses = {
    sm: 'px-2 py-1 text-xs gap-1',
    md: 'px-3 py-1.5 text-xs sm:text-sm gap-1.5',
    lg: 'px-4 py-2 text-sm sm:text-base gap-2',
  }[size];

  const variantClasses = {
    primary: isSpeakingThis
      ? 'bg-rose-600 text-white hover:bg-rose-700 shadow-sm'
      : 'bg-stone-900 text-white hover:bg-stone-800 shadow-sm',
    secondary: isSpeakingThis
      ? 'bg-rose-100 text-rose-800 border border-rose-300'
      : 'bg-stone-100 text-stone-700 hover:bg-stone-200 border border-stone-200',
    ghost: isSpeakingThis
      ? 'text-rose-600 hover:bg-rose-50'
      : 'text-stone-500 hover:text-stone-900 hover:bg-stone-100',
  }[variant];

  return (
    <button
      type="button"
      onClick={handleToggle}
      title={
        isSpeakingThis
          ? lang === 'tr'
            ? 'Sesi Durdur'
            : 'Stop Audio'
          : lang === 'tr'
          ? 'Sesli Dinle'
          : 'Listen Aloud'
      }
      className={`inline-flex items-center rounded-lg font-medium transition-all cursor-pointer whitespace-nowrap ${sizeClasses} ${variantClasses} ${className}`}
    >
      {isSpeakingThis ? (
        <>
          <VolumeX className="w-3.5 h-3.5 animate-pulse text-rose-600 shrink-0" />
          {label && (
            <span className="font-semibold text-rose-700">
              {lang === 'tr' ? 'Durdur' : 'Stop'}
            </span>
          )}
        </>
      ) : (
        <>
          <Volume2 className="w-3.5 h-3.5 shrink-0" />
          {label && <span>{label}</span>}
        </>
      )}
    </button>
  );
};
