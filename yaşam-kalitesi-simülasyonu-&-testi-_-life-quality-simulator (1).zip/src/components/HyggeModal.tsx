import React from 'react';
import { X, Sparkles, Coffee, Heart, Flame } from 'lucide-react';
import { Language } from '../data/quizData';
import { AudioSpeakerButton } from './AudioSpeakerButton';

interface HyggeModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const HyggeModal: React.FC<HyggeModalProps> = ({ isOpen, onClose, lang }) => {
  if (!isOpen) return null;

  const isTr = lang === 'tr';

  const manifestItemsTr = [
    { num: 1, title: 'Atmosfer', desc: 'Mumlarla “doğal ışık” yaratmak.' },
    { num: 2, title: 'Anda Kalmak', desc: 'Geçmiş ve gelecek değil, yaşanan ana odaklanmak.' },
    { num: 3, title: 'Küçük Keyifler', desc: 'Kahve, çikolata, küçük tatlı ve kurabiyeler…' },
    { num: 4, title: 'Eşitlik', desc: 'Misafirlikte herkes işin ucundan tutup, sofra birlikte hazırlanacak ve toplanacak.' },
    { num: 5, title: 'Şükretmek', desc: 'Sahip olduğumuz şeylerin kıymetini bilmek.' },
    { num: 6, title: 'Uyum', desc: 'Çevre ile uyum içinde olmak gerekiyor. Ego yapmak ve hava atmak yok.' },
    { num: 7, title: 'Rahatlık', desc: 'Rahat koltuklar ve giysiler...' },
    { num: 8, title: 'Ateşkes', desc: 'Siyaset, din gibi gerginlik çıkabilecek konuların yeri yok.' },
    { num: 9, title: 'Birliktelik', desc: 'Sevdiklerimizle birlikte olmak.' },
    { num: 10, title: 'Sığınak', desc: 'Kendini güvende hissetmek, tehlikeden korunduğunu bilmek.' },
  ];

  const manifestItemsEn = [
    { num: 1, title: 'Atmosphere', desc: 'Create natural, warm lighting with candles.' },
    { num: 2, title: 'Presence', desc: 'Focus on the present moment, rather than the past or the future.' },
    { num: 3, title: 'Simple Pleasures', desc: 'Coffee, chocolate, small pastries, and cookies…' },
    { num: 4, title: 'Equality', desc: 'True hospitality where everyone pitches in; setting and clearing the table together.' },
    { num: 5, title: 'Gratitude', desc: 'Appreciating what we have and cherishing simple blessings.' },
    { num: 6, title: 'Harmony', desc: 'Living in harmony with your environment. No competition or egos.' },
    { num: 7, title: 'Comfort', desc: 'Relaxed seating, cozy knitwear, and effortless ease.' },
    { num: 8, title: 'Truce', desc: 'Setting aside tense politics and divisive debates for peace.' },
    { num: 9, title: 'Togetherness', desc: 'Sharing meaningful time with the people we love.' },
    { num: 10, title: 'Sanctuary', desc: 'Feeling safe, protected, and fully at peace.' },
  ];

  const manifestItems = isTr ? manifestItemsTr : manifestItemsEn;

  const fullTextToRead = isTr
    ? `Hygge Felsefesi. Son yılların yeni akımlarından biri Hygge, Hüge diye okunan, Danca bir kelime. Mutluluk, sıcaklık ve huzur anlamlarına gelen Danimarka kültürüne özgü bu kavram, gösterişten uzak ve küçük mutluluklara odaklanarak yaşamak. Mumlar, paylaşılan dostluklar, sade bir yaşam, yemek muhabbetleri, sıcak bir battaniye, rahat ve minimal mobilyalar... Özellikle büyük şehirlerde sıkışık trafik, koşuşturmalar ve fazlaca negatif olaylar gibi nedenlerle üzerimizdeki stresi atarak rahatlamaya ihtiyacımız var. İşte bunun için, Hygge felsefesini uygulayarak bir nebzede olsa keyifli bir yaşam sürdürebiliriz. Keyif, rahatlık, samimiyet… Hygge Manifestosu: ${manifestItemsTr
        .map((m) => `${m.num}. ${m.title}: ${m.desc}`)
        .join('. ')}`
    : `The Hygge Philosophy. Pronounced 'hoo-ga', Hygge is a Danish concept embodying comfort, warmth, and contented well-being. It focuses on the quiet beauty of everyday life, unhurried gatherings, a steaming cup of coffee, home-baked treats, candlelight, and peaceful presence.`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/60 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="bg-white border-2 border-stone-800 rounded-2xl max-w-2xl w-full my-auto max-h-[92vh] flex flex-col shadow-2xl overflow-hidden ring-1 ring-stone-900/20"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Header */}
        <div className="bg-stone-900 text-stone-100 px-5 sm:px-6 py-4 flex items-center justify-between border-b border-stone-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300">
              <Flame className="w-4 h-4" />
            </span>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 block">
                {isTr ? 'Danimarka Yaşam Kültürü' : 'Danish Lifestyle Philosophy'}
              </span>
              <h2 className="text-lg sm:text-xl font-extrabold text-white leading-tight">
                {isTr ? 'Hygge Felsefesi' : 'The Hygge Philosophy'}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <AudioSpeakerButton
              textToSpeak={fullTextToRead}
              lang={lang}
              size="sm"
              variant="ghost"
              className="text-stone-300 hover:text-white hover:bg-stone-800"
              label={isTr ? 'Sesli Dinle' : 'Listen'}
            />
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
              title={isTr ? 'Kapat' : 'Close'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-5 sm:p-7 space-y-6 text-stone-700 leading-relaxed text-sm sm:text-base">
          {/* Hygge Visual Asset: Book, Coffee & Cake */}
          <div className="rounded-xl overflow-hidden border border-stone-200 shadow-sm bg-stone-100">
            <img
              src="/src/assets/images/hygge_coffee_cake_1790882435108.jpg"
              alt={isTr ? 'Hygge: Kitap, Kahve ve Ev Yapımı Kek' : 'Hygge: Book, Coffee and Homemade Cake'}
              className="w-full h-52 sm:h-64 object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="px-4 py-2 bg-stone-50 border-t border-stone-200 flex items-center justify-between text-xs text-stone-500 font-medium">
              <span className="flex items-center gap-1.5">
                <Coffee className="w-3.5 h-3.5 text-amber-700" />
                {isTr ? 'Hygge Anı: Kitap, sıcak kahve ve kek eşliğinde dinginlik' : 'Hygge Moment: Serenity with book, hot coffee and cake'}
              </span>
              <span className="text-[11px] text-stone-400 font-mono">Danimarka</span>
            </div>
          </div>

          {/* Main Hygge Article Narrative */}
          <div className="space-y-4 text-stone-800">
            <p className="text-stone-700 leading-relaxed">
              {isTr ? (
                <>
                  Son yılların yeni akımlarından biri <strong className="text-stone-950 font-bold">Hygge</strong>, <em>Hüge</em> diye okunan, Danca bir kelime. &apos;Mutluluk&apos;, &apos;sıcaklık&apos; ve &apos;huzur&apos; anlamlarına gelen Danimarka kültürüne özgü bu kavram, gösterişten uzak ve küçük mutluluklara odaklanarak yaşamak.
                </>
              ) : (
                <>
                  One of the most defining movements of recent years, <strong className="text-stone-950 font-bold">Hygge</strong> (pronounced <em>hoo-ga</em>), is a Danish word meaning happiness, warmth, and peace. Unique to Danish culture, it embraces living without pretension and focusing on everyday small joys.
                </>
              )}
            </p>

            <p className="text-stone-700 leading-relaxed">
              {isTr ? (
                <>
                  Mumlar, paylaşılan dostluklar, sade bir yaşam, yemek muhabbetleri, sıcak bir battaniye, rahat ve minimal mobilyalar... Özellikle büyük şehirlerde; sıkışık trafik, koşuşturmalar ve fazlaca negatif olaylar gibi nedenlerle üzerimizdeki stresi atarak rahatlamaya ihtiyacımız var. İşte bunun için, Hygge felsefesini uygulayarak bir nebzede olsa keyifli bir yaşam sürdürebiliriz.
                </>
              ) : (
                <>
                  Candles, shared friendships, simple living, cozy conversations over food, warm blankets, relaxed and minimalist comfort... Especially in metropolitan cities with traffic jams, relentless rush, and everyday stress, we need to release tension and recharge. By practicing Hygge, we can nurture a calmer, more joyful life.
                </>
              )}
            </p>

            {/* Hygge Core Essence Pill */}
            <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-3.5 sm:p-4 text-center my-4">
              <span className="text-base sm:text-lg font-bold text-amber-950 tracking-wide flex items-center justify-center gap-2">
                <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
                {isTr ? 'Keyif, rahatlık, samimiyet…' : 'Joy, comfort, togetherness…'}
                <Sparkles className="w-4 h-4 text-amber-600" />
              </span>
            </div>
          </div>

          {/* Hygge Manifesto Section */}
          <div className="pt-2">
            <div className="flex items-center gap-2 mb-4 border-b border-stone-200 pb-2">
              <Flame className="w-5 h-5 text-amber-600" />
              <h3 className="text-base sm:text-lg font-bold text-stone-900 uppercase tracking-tight">
                {isTr ? 'Hygge Manifestosu' : 'The Hygge Manifesto'}
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {manifestItems.map((item) => (
                <div
                  key={item.num}
                  className="p-3.5 rounded-xl border border-stone-200 bg-white hover:border-amber-400 hover:bg-amber-50/20 transition-all flex items-start gap-3 shadow-2xs"
                >
                  <div className="w-7 h-7 rounded-lg bg-stone-900 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                    {item.num}
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-0.5">
                      {item.title}
                    </h4>
                    <p className="text-xs sm:text-sm text-stone-600 leading-snug">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Source Citation */}
            <div className="mt-5 pt-3 border-t border-stone-200 flex items-center justify-end text-xs text-stone-500">
              <span className="font-semibold text-stone-700 bg-stone-100 px-3 py-1 rounded-md border border-stone-200">
                Kaynak: Key For Managers
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-stone-50 px-5 sm:px-6 py-3.5 border-t border-stone-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-stone-500">
            <span className="font-semibold text-stone-700">Kaynak: Key For Managers</span>
            <span aria-hidden="true" className="text-stone-300">·</span>
            <span className="italic hidden sm:inline">
              {isTr ? 'Küçük anların değerini bilin.' : 'Cherish the simple, present moments.'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs sm:text-sm font-bold bg-stone-900 text-white hover:bg-stone-800 transition-colors cursor-pointer shadow-xs"
          >
            {isTr ? 'Anladım / Kapat' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
