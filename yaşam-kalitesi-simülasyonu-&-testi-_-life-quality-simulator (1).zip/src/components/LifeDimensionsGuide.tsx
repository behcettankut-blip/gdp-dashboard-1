import React, { useState } from 'react';
import { QUESTIONS, Language } from '../data/quizData';
import { UI_TRANSLATIONS } from '../data/translations';
import { AudioSpeakerButton } from './AudioSpeakerButton';
import { BookOpen, Heart, Info, ExternalLink } from 'lucide-react';

interface LifeDimensionsGuideProps {
  onStartQuiz: () => void;
  lang: Language;
}

export const LifeDimensionsGuide: React.FC<LifeDimensionsGuideProps> = ({ onStartQuiz, lang }) => {
  const [imgError, setImgError] = useState(false);
  const t = UI_TRANSLATIONS[lang];

  const guideSpeech =
    lang === 'tr'
      ? '10 Yaşam Boyutu Rehberi. Yaşam kalitesi yalnızca maddi olanaklarla ya da sadece sağlıkla sınırlı değildir. Modern sosyolojik ve psikolojik araştırmalar, dengeli bir yaşamın 10 temel bileşenin uyumuyla mümkün olduğunu göstermektedir.'
      : '10 Life Dimensions Guide. Quality of life is not solely confined to material abundance or health alone. Sociological research demonstrates that balanced vitality stems from the dynamic harmony across 10 vital life pillars.';

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8 pb-16">
      {/* Intro Header */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-10 shadow-xs">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-stone-500">
                <BookOpen className="w-4 h-4 text-stone-700" />
                <span>
                  {lang === 'tr' ? 'Bütünsel Yaşam Rehberi' : 'Holistic Life Blueprint'}
                </span>
              </div>

              <AudioSpeakerButton
                textToSpeak={guideSpeech}
                lang={lang}
                size="sm"
                variant="ghost"
              />
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight mb-4 text-balance">
              {lang === 'tr'
                ? 'Testteki 10 Boyut Hayatımızı Nasıl Şekillendirir?'
                : 'How Do the 10 Dimensions Anchor Our Wellbeing?'}
            </h2>
            <p className="text-stone-600 text-sm leading-relaxed mb-6">
              {lang === 'tr'
                ? 'Yaşam kalitesi yalnızca maddi olanaklarla ya da sadece sağlıkla sınırlı değildir. Modern sosyolojik ve psikolojik araştırmalar, dengeli bir yaşamın 10 temel bileşenin uyumuyla mümkün olduğunu göstermektedir.'
                : 'Quality of life is not merely an absence of illness or accumulation of wealth. Real equilibrium requires synergy across physical health, career fulfillment, human love, social trust, personal hobbies, and sacred quiet.'}
            </p>
            <button
              onClick={onStartQuiz}
              className="px-5 py-2.5 rounded-lg bg-stone-900 text-white text-xs sm:text-sm font-bold hover:bg-stone-800 transition-colors cursor-pointer"
            >
              {t.nav.startTest}
            </button>
          </div>

          <div className="lg:col-span-5">
            <div className="aspect-4/3 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 relative">
              {!imgError ? (
                <img
                  src="/src/assets/images/life_dimensions_1790788433603.jpg"
                  alt="Dengeli yaşam taşları ve doğa"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-6 text-stone-400">
                  <Heart className="w-10 h-10 mb-2" />
                  <span className="text-xs">Yaşam Dengesi Sanatı</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 10 Items Cards */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-stone-900 px-1">
          {lang === 'tr'
            ? '10 Yaşam Boyutunun Ayrıntılı Analizi & Önemi'
            : 'Detailed Analysis & Significance of All 10 Dimensions'}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {QUESTIONS.map((q) => (
            <div
              key={q.id}
              className="bg-white border border-stone-200 rounded-xl p-5 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-bold font-mono text-stone-400">
                    #{q.id}
                  </span>
                  <span className="text-xs font-bold px-2 py-0.5 rounded bg-stone-100 text-stone-700">
                    {q.category[lang]}
                  </span>
                </div>

                <h4 className="text-base font-bold text-stone-900 mb-2">
                  {q.question[lang]}
                </h4>

                <p className="text-xs text-stone-600 leading-relaxed mb-4">
                  {q.significance[lang]}
                </p>
              </div>

              <div className="pt-3 border-t border-stone-100 text-xs text-stone-500">
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="font-bold text-stone-800">
                    {lang === 'tr' ? 'Öneri & Odak:' : 'Recommended Focus:'} {q.recommendation.title[lang]}
                  </span>
                </div>
                <p className="leading-relaxed mb-1">{q.recommendation.advice[lang]}</p>
                {q.recommendation.actionSteps[lang]
                  .filter((s) => s.startsWith('Not:') || s.startsWith('Note:'))
                  .map((noteStep, idx) => {
                    const urlRegex = /(https?:\/\/[^\s]+)/g;
                    const parts = noteStep.split(urlRegex);
                    return (
                      <div
                        key={idx}
                        className="mt-2.5 p-2.5 rounded-lg bg-amber-50/90 border border-amber-200/80 text-xs text-stone-800 flex items-start gap-2"
                      >
                        <Info className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
                        <div className="leading-relaxed">
                          {parts.map((part, i) =>
                            part.match(urlRegex) ? (
                              <a
                                key={i}
                                href={part}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-sky-700 hover:text-sky-900 underline underline-offset-2 break-all font-semibold inline-flex items-center gap-0.5 mx-0.5"
                              >
                                <span>{part}</span>
                                <ExternalLink className="w-3 h-3 inline-block shrink-0 text-sky-600" />
                              </a>
                            ) : (
                              part
                            )
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
