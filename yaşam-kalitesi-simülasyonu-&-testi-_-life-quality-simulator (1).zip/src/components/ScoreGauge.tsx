import React from 'react';
import { ScoreTier, Language } from '../data/quizData';

interface ScoreGaugeProps {
  score: number;
  currentTier: ScoreTier;
  lang?: Language;
}

export const ScoreGauge: React.FC<ScoreGaugeProps> = ({ score, currentTier, lang = 'tr' }) => {
  const percentage = Math.min(100, Math.max(0, (score / 10) * 100));

  const tierLabel = currentTier.label[lang];

  return (
    <div className="w-full bg-white border border-stone-200 rounded-xl p-5 sm:p-6 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
        <div>
          <span className="text-xs uppercase tracking-wider text-stone-500 font-semibold">
            {lang === 'tr' ? 'Puan Değerlendirme Skalası' : 'Score Evaluation Scale'}
          </span>
          <h4 className="text-base sm:text-lg font-semibold text-stone-900 mt-0.5">
            {lang === 'tr' ? (
              <>
                10 Üzerinden <span className="tabular-nums font-bold">{score}</span> Puan · {tierLabel}
              </>
            ) : (
              <>
                <span className="tabular-nums font-bold">{score}</span> of 10 Points · {tierLabel}
              </>
            )}
          </h4>
        </div>
        <div className="text-xs text-stone-500">
          {lang === 'tr' ? 'Skala:' : 'Range:'}{' '}
          <span className="tabular-nums font-medium text-stone-700">0 - 10</span>
        </div>
      </div>

      {/* Progress Track with 4 Segments */}
      <div className="relative pt-6 pb-2">
        {/* Pointer Pin above the bar */}
        <div
          className="absolute top-0 -translate-x-1/2 transition-all duration-500 flex flex-col items-center z-10"
          style={{ left: `${percentage}%` }}
        >
          <div className="bg-stone-900 text-white text-[11px] font-bold px-2 py-0.5 rounded shadow-sm whitespace-nowrap tabular-nums">
            {score} {lang === 'tr' ? 'Puan' : 'Pts'}
          </div>
          <div className="w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-stone-900 mt-0.5" />
        </div>

        {/* Multi-segmented bar */}
        <div className="h-3 w-full bg-stone-100 rounded-full overflow-hidden flex">
          {/* Segment 1: 0-3 (30%) ÇOK KÖTÜ / VERY POOR */}
          <div
            className={`h-full transition-opacity ${
              score <= 3 ? 'bg-rose-500' : 'bg-rose-200'
            }`}
            style={{ width: '30%' }}
            title="0-3: Çok Kötü / Very Poor"
          />
          {/* Segment 2: 4-5 (20%) KÖTÜ / POOR */}
          <div
            className={`h-full border-l border-white transition-opacity ${
              score >= 4 && score <= 5 ? 'bg-amber-500' : 'bg-amber-200'
            }`}
            style={{ width: '20%' }}
            title="4-5: Kötü / Poor"
          />
          {/* Segment 3: 6-7 (20%) İYİ / GOOD */}
          <div
            className={`h-full border-l border-white transition-opacity ${
              score >= 6 && score <= 7 ? 'bg-teal-500' : 'bg-teal-200'
            }`}
            style={{ width: '20%' }}
            title="6-7: İyi / Good"
          />
          {/* Segment 4: 8-10 (30%) ÇOK İYİ / VERY GOOD */}
          <div
            className={`h-full border-l border-white transition-opacity ${
              score >= 8 ? 'bg-emerald-500' : 'bg-emerald-200'
            }`}
            style={{ width: '30%' }}
            title="8-10: Çok İyi / Excellent"
          />
        </div>

        {/* Labels below the bar */}
        <div className="grid grid-cols-4 text-center mt-3 text-xs text-stone-500 font-medium">
          <div className={`text-left ${score <= 3 ? 'text-rose-700 font-bold' : ''}`}>
            <span className="block text-[11px] text-stone-400">1 - 3</span>
            <span>{lang === 'tr' ? 'Çok Kötü' : 'Very Low'}</span>
          </div>
          <div className={`text-center ${score >= 4 && score <= 5 ? 'text-amber-700 font-bold' : ''}`}>
            <span className="block text-[11px] text-stone-400">4 - 5</span>
            <span>{lang === 'tr' ? 'Kötü' : 'Poor'}</span>
          </div>
          <div className={`text-center ${score >= 6 && score <= 7 ? 'text-teal-700 font-bold' : ''}`}>
            <span className="block text-[11px] text-stone-400">6 - 7</span>
            <span>{lang === 'tr' ? 'İyi' : 'Good'}</span>
          </div>
          <div className={`text-right ${score >= 8 ? 'text-emerald-700 font-bold' : ''}`}>
            <span className="block text-[11px] text-stone-400">8 - 10</span>
            <span>{lang === 'tr' ? 'Çok İyi' : 'Excellent'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
