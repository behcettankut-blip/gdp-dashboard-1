export type Language = 'tr' | 'en';

export interface QuizOption {
  key: 'a' | 'b';
  label: {
    tr: string;
    en: string;
  };
}

export interface Question {
  id: number;
  category: {
    tr: string;
    en: string;
  };
  categorySlug: 'health' | 'living' | 'education' | 'career' | 'relationship' | 'social' | 'finance' | 'leisure' | 'spiritual' | 'vacation';
  domainName: {
    tr: string;
    en: string;
  };
  question: {
    tr: string;
    en: string;
  };
  options: QuizOption[];
  positiveAnswer: 'a' | 'b';
  positiveLabel: {
    tr: string;
    en: string;
  };
  significance: {
    tr: string;
    en: string;
  };
  recommendation: {
    title: {
      tr: string;
      en: string;
    };
    advice: {
      tr: string;
      en: string;
    };
    actionSteps: {
      tr: string[];
      en: string[];
    };
    impactRating: number; // 1-5 impact on overall well-being
    timeToSeeChange: {
      tr: string;
      en: string;
    };
  };
}

export interface ScoreTier {
  id: 'very_poor' | 'poor' | 'good' | 'very_good';
  minScore: number;
  maxScore: number;
  label: {
    tr: string;
    en: string;
  };
  badgeLabel: {
    tr: string;
    en: string;
  };
  tone: 'rose' | 'amber' | 'teal' | 'emerald';
  description: {
    tr: string;
    en: string;
  };
  summary: {
    tr: string;
    en: string;
  };
  actionMessage: {
    tr: string;
    en: string;
  };
}

export const SCORE_TIERS: ScoreTier[] = [
  {
    id: 'very_poor',
    minScore: 0,
    maxScore: 3,
    label: {
      tr: 'ÇOK KÖTÜ',
      en: 'CRITICAL / VERY LOW',
    },
    badgeLabel: {
      tr: 'Acil İlgi Gerektiren Seviye',
      en: 'Requires Immediate Focus',
    },
    tone: 'rose',
    description: {
      tr: 'Yaşam kalitesi göstergelerinizde belirgin zorluklar ve hoşnutsuzluklar tespit edildi.',
      en: 'Significant challenges and low satisfaction detected across fundamental life areas.',
    },
    summary: {
      tr: 'Günlük hayatınızın önemli temel taşlarında (sağlık, maddi şartlar, sosyal bağlar veya iş ortamı) hissedilir bir tükenmişlik yaşanıyor olabilir.',
      en: 'You may be experiencing noticeable burnout or strain across critical pillars such as health, finances, social ties, or work environment.',
    },
    actionMessage: {
      tr: 'Öncelikli olarak en çok zorlandığınız 1-2 alandan başlayarak küçük ama sürdürülebilir değişim adımları belirlemeniz önerilir.',
      en: 'We recommend starting with small, sustainable micro-habits focusing on your 1-2 most challenging areas first.',
    },
  },
  {
    id: 'poor',
    minScore: 4,
    maxScore: 5,
    label: {
      tr: 'KÖTÜ',
      en: 'POOR / VULNERABLE',
    },
    badgeLabel: {
      tr: 'Gelişime Açık Seviye',
      en: 'Open for Growth',
    },
    tone: 'amber',
    description: {
      tr: 'Bazı temel alanlarda olumlu dayanaklarınız bulunurken, belirli eksiklikler genel doyumunuzu sınırlıyor.',
      en: 'While you possess positive foundations in certain areas, notable deficits are limiting your overall life satisfaction.',
    },
    summary: {
      tr: 'Hayatınızın yarısında olumlu koşullara sahipsiniz ancak kalan alanlardaki memnuniyetsizlikler toplam yaşam konforunuzu aşağı çekiyor.',
      en: 'About half of your life parameters are healthy, but unfulfilled needs in the remaining areas are holding back your daily vitality.',
    },
    actionMessage: {
      tr: 'Eksik puan aldığınız alanları (örneğin hobiler, tatil, iş veya ev ortamı) belirleyip dengeyi kuracak haftalık alışkanlıklar edinebilirsiniz.',
      en: 'Identify the deficit areas (such as hobbies, vacations, career, or home space) and set consistent weekly commitments.',
    },
  },
  {
    id: 'good',
    minScore: 6,
    maxScore: 7,
    label: {
      tr: 'İYİ',
      en: 'GOOD / BALANCED',
    },
    badgeLabel: {
      tr: 'Dengeli Seviye',
      en: 'Balanced & Steady',
    },
    tone: 'teal',
    description: {
      tr: 'Tebrikler! Yaşamınızın genelinde sağlıklı, dengeli ve memnuniyet verici bir standarda sahipsiniz.',
      en: 'Congratulations! You enjoy a healthy, well-adjusted, and generally satisfying standard of living.',
    },
    summary: {
      tr: 'Çoğu göstergede pozitif durumdasınız. Eksik kalan 3-4 alan üzerinde bilinçli ayarlamalar yaparak çok daha yüksek bir doyum seviyesine rahatlıkla çıkabilirsiniz.',
      en: 'You are on positive footing across most indicators. Fine-tuning the remaining 3-4 dimensions can smoothly elevate you to the top tier.',
    },
    actionMessage: {
      tr: 'Mevcut kazanımlarınızı korurken eksik kalan alanlara küçük zaman dilimleri ayırmak refahınızı zirveye taşıyacaktır.',
      en: 'Sustaining current wins while scheduling focused time for weaker dimensions will unlock exceptional vitality.',
    },
  },
  {
    id: 'very_good',
    minScore: 8,
    maxScore: 10,
    label: {
      tr: 'ÇOK İYİ',
      en: 'EXCELLENT / OPTIMAL',
    },
    badgeLabel: {
      tr: 'Yüksek Yaşam Kalitesi',
      en: 'High Quality of Life',
    },
    tone: 'emerald',
    description: {
      tr: 'Mükemmel bir yaşam dengesi ve yüksek hayat tatmini.',
      en: 'Outstanding life balance and exceptional personal satisfaction.',
    },
    summary: {
      tr: 'Fiziksel sağlık, iş tatmini, duygusal bağlar, maddi denge ve kişisel zaman yönetiminde oldukça başarılı bir hayat kurgulamışsınız.',
      en: 'You have orchestrated harmony across physical vitality, career fulfillment, relationships, finances, and personal leisure.',
    },
    actionMessage: {
      tr: 'Bu harika ritmi ve şükran duygusunu korumaya devam edin; çevrenize de ilham kaynağı olabilirsiniz.',
      en: 'Maintain this inspiring lifestyle and mindfulness; your habits are a benchmark and inspiration for those around you.',
    },
  },
];

export const QUESTIONS: Question[] = [
  {
    id: 1,
    category: {
      tr: 'Fiziksel Sağlık',
      en: 'Physical Health',
    },
    categorySlug: 'health',
    domainName: {
      tr: 'Sağlık ve Zindelik',
      en: 'Vitality & Well-being',
    },
    question: {
      tr: 'Sağlığınız nasıl ?',
      en: 'How is your general health condition?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Sağlık sorunum yok.',
          en: 'I have no health problems.',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Sağlığım iyi değil, şikayetlerim var.',
          en: 'My health is not good; I have physical complaints.',
        },
      },
    ],
    positiveAnswer: 'a',
    positiveLabel: {
      tr: 'Sağlık sorunum yok (İyi sağlık)',
      en: 'No major health issues (Good health)',
    },
    significance: {
      tr: 'Beden sağlığı, tüm diğer yaşam hedeflerinin ve mutluluğun temel taşıdır.',
      en: 'Physical wellness is the foundational bedrock for all happiness and productivity.',
    },
    recommendation: {
      title: {
        tr: 'Beden Farkındalığı & Koruyucu Sağlık',
        en: 'Body Awareness & Preventive Health',
      },
      advice: {
        tr: 'Kronik şikayetleri ertelememek, düzenli hekim kontrolleri ve günlük hareket enerjinizi belirgin şekilde artırır.',
        en: 'Do not postpone recurring complaints. Regular health screenings and daily movement create immediate vitality.',
      },
      actionSteps: {
        tr: [
          'Düzenli yıllık hekim kontrolü ve kan tahlillerinizi yaptırın.',
          'Günde en az 25-30 dakika tempolu yürüyüşü günlük rutine ekleyin.',
          'Gece uyku hijyenini sağlamak için yatmadan 1 saat önce mavi ışığı kesin.',
        ],
        en: [
          'Schedule an annual check-up and comprehensive blood panel.',
          'Incorporate at least 25-30 minutes of brisk daily walking into your routine.',
          'Unplug from screens 1 hour before bedtime to restore sleep architecture.',
        ],
      },
      impactRating: 5,
      timeToSeeChange: {
        tr: '2 - 4 Hafta',
        en: '2 - 4 Weeks',
      },
    },
  },
  {
    id: 2,
    category: {
      tr: 'Yaşam Alanı',
      en: 'Living Space',
    },
    categorySlug: 'living',
    domainName: {
      tr: 'Ev ve Mekan Huzuru',
      en: 'Home Environment & Sanctuary',
    },
    question: {
      tr: 'Oturduğunuz evden memnun musunuz?',
      en: 'Are you satisfied with the home you live in?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Hayır',
          en: 'No',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Evet',
          en: 'Yes',
        },
      },
    ],
    positiveAnswer: 'b',
    positiveLabel: {
      tr: 'Evet (Evimden memnunum)',
      en: 'Yes (Satisfied with my home)',
    },
    significance: {
      tr: 'Ev, günün stresini attığınız ve kendinizi güvende hissettiğiniz sığınağınızdır.',
      en: 'Home is your daily sanctuary to decompress, reset, and feel completely secure.',
    },
    recommendation: {
      title: {
        tr: 'Yaşam Alanını Sadeleştirme & Huzur Köşesi',
        en: 'Decluttering & Sanctuary Creation',
      },
      advice: {
        tr: 'Ev ortamı zihinsel dinginliğin doğrudan aynasıdır. Taşınmak şart değildir; mikro düzenlemeler havayı değiştirir.',
        en: 'Your living quarters directly mirror mental calmness. Moving is not mandatory; micro-enhancements shift energy.',
      },
      actionSteps: {
        tr: [
          'Evinizde kullanmadığınız fazlalıklardan arınmak için 3 kutu (at/bağışla/tut) kuralını uygulayın.',
          'Dinlenme ve okuma alanınızı doğal ışık, yeşil bir bitki ve sıcak bir lamba ile yeniden düzenleyin.',
          'Gürültü ve hava sirkülasyonunu iyileştirmek için basit tedbirler alın.',
          'Eğer ev ve lokasyondan memnun değilseniz, bütçeniz yeterli olduğunda evinizi değiştirin.',
        ],
        en: [
          'Declutter unused clutter using the 3-box rule (donate, discard, keep).',
          'Create a dedicated recharge nook with natural lighting, a green plant, and a warm lamp.',
          'Optimize room airflow and sound insulation through simple acoustic textiles.',
          'If you are dissatisfied with your home and location, plan to relocate when your budget allows.',
        ],
      },
      impactRating: 4,
      timeToSeeChange: {
        tr: '1 Hafta',
        en: '1 Week',
      },
    },
  },
  {
    id: 3,
    category: {
      tr: 'Eğitim & Yetkinlik',
      en: 'Education & Mastery',
    },
    categorySlug: 'education',
    domainName: {
      tr: 'Bilişsel & Mesleki Yeterlilik',
      en: 'Intellectual & Professional Competence',
    },
    question: {
      tr: 'Almış olduğunuz eğitim yeterli mi ?',
      en: 'Do you feel the education you received is sufficient?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Hayır',
          en: 'No',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Evet',
          en: 'Yes',
        },
      },
    ],
    positiveAnswer: 'b',
    positiveLabel: {
      tr: 'Evet (Eğitimim yeterli)',
      en: 'Yes (Education is sufficient)',
    },
    significance: {
      tr: 'Öz yeterlilik hissi, dünyadaki adaptasyon kabiliyetinizi ve özgüveninizi güçlendirir.',
      en: 'A sense of self-competence fuels career adaptability and enduring self-esteem.',
    },
    recommendation: {
      title: {
        tr: 'Yaşam Boyu Öğrenme & Yeni Beceriler',
        en: 'Lifelong Learning & Upskilling',
      },
      advice: {
        tr: 'Öğrenme diploma ile bitmez. Dijital çağda haftada 2 saatlik planlı gelişim öz yeterlilik algısını dönüştürür.',
        en: 'Education never concludes with a diploma. Dedicated 2 weekly hours of modern upskilling transforms self-efficacy.',
      },
      actionSteps: {
        tr: [
          'İlgi duyduğunuz bir konu veya mesleki beceri için online bir kursa başlayın.',
          'Aylık en az 1 derin araştırma kitabı veya sesli kitap bitirme hedefi koyun.',
          'Yeni bir dil veya dijital araç öğrenerek zihinsel esnekliğinizi artırın.',
          'Belli bir zaman için; “öğrenme projesi” tamamlayın. Örneğin bir ay finans, sonraki ay yapay zekâ, sonraki ay liderlik gibi bir konu seçip ay sonunda somut bir çıktı oluşturun.',
        ],
        en: [
          'Enroll in an interactive course for a modern skill or personal curiosity.',
          'Set a target to read or listen to at least one insightful book per month.',
          'Acquire a new language or digital tool to expand cognitive plasticity.',
          'Complete a defined "learning project" within a set timeframe. For example, choose finance for one month, AI the next, and leadership the following, creating a concrete deliverable by month-end.',
        ],
      },
      impactRating: 3,
      timeToSeeChange: {
        tr: '1 - 3 Ay',
        en: '1 - 3 Months',
      },
    },
  },
  {
    id: 4,
    category: {
      tr: 'Kariyer & İş Ortamı',
      en: 'Career & Work',
    },
    categorySlug: 'career',
    domainName: {
      tr: 'Çalışma Hayatı ve Mesleki Tatmin',
      en: 'Workplace Fulfillment & Harmony',
    },
    question: {
      tr: 'İşinizden ve iş ortamından memnun musunuz ?',
      en: 'Are you satisfied with your job and workplace environment?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Hayır',
          en: 'No',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Evet',
          en: 'Yes',
        },
      },
    ],
    positiveAnswer: 'b',
    positiveLabel: {
      tr: 'Evet (İşimden ve ortamımdan memnunum)',
      en: 'Yes (Satisfied with job & workplace)',
    },
    significance: {
      tr: 'Günün en verimli saatlerinin geçtiği iş ortamı, stres seviyenizi ve toplumsal bağınızı belirler.',
      en: 'Where you spend your peak daily hours dictates cortisol levels and sense of societal purpose.',
    },
    recommendation: {
      title: {
        tr: 'Profesyonel Sınırlar & Mesleki Ufuk',
        en: 'Work Boundaries & Strategic Career Alignment',
      },
      advice: {
        tr: 'İş memnuniyetsizliği kronik tükenmişliğe yol açar. Sağlıklı sınırlar çizmek veya proaktif adımlar atmak şarttır.',
        en: 'Chronic workplace dissatisfaction drives systemic exhaustion. Setting healthy boundaries and exploring new paths is essential.',
      },
      actionSteps: {
        tr: [
          'Mesai saatleri dışında iş mesajlarına yanıt vermeme kuralı koyarak net sınırlar çizin.',
          'Mevcut işinizde sizi motive eden 1-2 projeye ağırlık verin.',
          'Eğer ortam toksikse, kendinizi geliştirip, 6 aylık kariyer geçiş veya CV güncelleme planı hazırlayın.',
          'Not: Kariyerinizde yükselmek için; Liderlik, Finans ve Ekonomi \' yi kolayca https://btankut.blogspot.com/ Bloğunu takip ederek öğrenebilirsiniz.',
        ],
        en: [
          'Enforce strict digital boundaries after working hours regarding non-emergency messages.',
          'Negotiate focus on the 1-2 core projects that genuinely inspire your skills.',
          'If the environment is toxic, focus on personal growth and design a 6-month career pivot and portfolio update plan.',
          'Note: To advance in your career, you can easily learn Leadership, Finance & Economics by following the blog at https://btankut.blogspot.com/',
        ],
      },
      impactRating: 5,
      timeToSeeChange: {
        tr: '1 - 2 Ay',
        en: '1 - 2 Months',
      },
    },
  },
  {
    id: 5,
    category: {
      tr: 'Duygusal Yaşam',
      en: 'Romantic & Intimacy',
    },
    categorySlug: 'relationship',
    domainName: {
      tr: 'İkili İlişkiler ve Sevgi Bağı',
      en: 'Emotional Bonds & Partnership',
    },
    question: {
      tr: 'Eşiniz ya da sevgiliniz var mı?',
      en: 'Do you have a spouse or romantic partner?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Evet',
          en: 'Yes',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Hayır',
          en: 'No',
        },
      },
    ],
    positiveAnswer: 'a',
    positiveLabel: {
      tr: 'Evet (Eşim / sevgilim var)',
      en: 'Yes (Have a partner)',
    },
    significance: {
      tr: 'Duygusal yakınlık ve destekleyici bir eş, hayatın fırtınalarına karşı en güçlü psikolojik kalkandır.',
      en: 'Affectionate intimacy and a supportive partner act as a potent buffer against life’s stresses.',
    },
    recommendation: {
      title: {
        tr: 'Duygusal Açıklık & Öz Şefkat',
        en: 'Emotional Openness & Self-Compassion',
      },
      advice: {
        tr: 'İlişki durumu tek başına mutluluk reçetesi değildir; ancak sevgi alışverişine açık olmak ve önce kendinle barışık olmak esastır.',
        en: 'A relationship alone does not guarantee joy; cultivating deep intimacy readiness and inner self-love is pivotal.',
      },
      actionSteps: {
        tr: [
          'Yeni insanlarla tanışabileceğiniz ilgi kulüplerine, kültürel etkinliklere katılın.',
          'Yalnızlık hissini bastırmak yerine kendinizle kaliteli vakit geçirme sanatını uygulayın.',
          'İlişkiniz varsa haftada 1 akşam baş başa derin sohbet randevusu belirleyin.',
        ],
        en: [
          'Engage in hobby clubs or community groups where meaningful connections naturally form.',
          'Practice intentional self-dates rather than passively numbing alone time.',
          'If partnered, institute a weekly distraction-free evening for deep dialogue and reconnection.',
        ],
      },
      impactRating: 4,
      timeToSeeChange: {
        tr: '2 - 6 Hafta',
        en: '2 - 6 Weeks',
      },
    },
  },
  {
    id: 6,
    category: {
      tr: 'Sosyal Çevre',
      en: 'Social Circle',
    },
    categorySlug: 'social',
    domainName: {
      tr: 'Dostluk ve Sosyal Destek',
      en: 'Friendship & Social Support',
    },
    question: {
      tr: 'Arkadaş çevrenizden memnun musunuz ?',
      en: 'Are you satisfied with your social circle and friends?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Evet',
          en: 'Yes',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Hayır',
          en: 'No',
        },
      },
    ],
    positiveAnswer: 'a',
    positiveLabel: {
      tr: 'Evet (Arkadaş çevremden memnunum)',
      en: 'Yes (Satisfied with friend circle)',
    },
    significance: {
      tr: 'Güvenilir dostluklar, psikolojik dayanıklılığı artıran ve yalnızlığı önleyen temel unsurdur.',
      en: 'Trustworthy friendships are the strongest deterrent against chronic loneliness and emotional fatigue.',
    },
    recommendation: {
      title: {
        tr: 'Nitelikli Sosyal Ağ & Toksik İlişkileri Ayıklama',
        en: 'High-Quality Social Circle & Boundary Pruning',
      },
      advice: {
        tr: 'Arkadaşlıkta nicelik değil, nitelik önemlidir. Enerjinizi tüketen çevreler yerine samimi 2-3 dosta odaklanın.',
        en: 'Quality triumphs over quantity in friendships. Divert attention away from draining circles into 2-3 genuine confidants.',
      },
      actionSteps: {
        tr: [
          'Sizi koşulsuz dinleyen ve iyi gelen 1-2 eski dostunuzu bu hafta arayın veya kahveye davet edin.',
          'Sürekli şikayet eden veya sizi küçümseyen ortamlara sınır koyarak mesafenizi koruyun.',
          'Ortak değerleri paylaştığınız bir gönüllülük projesine dahil olun.',
          'Yeni insanlarla tanışabileceğiniz ilgi kulüplerine, kültürel etkinliklere katılın.',
        ],
        en: [
          'Reach out to 1-2 authentic friends who uplift you for a heartfelt coffee catch-up this week.',
          'Set compassionate distance from gossiping or cynically draining acquaintances.',
          'Volunteer in an organization whose core values echo your personal worldview.',
          'Join interest clubs and cultural events where you can meet new and like-minded people.',
        ],
      },
      impactRating: 4,
      timeToSeeChange: {
        tr: '1 - 3 Hafta',
        en: '1 - 3 Weeks',
      },
    },
  },
  {
    id: 7,
    category: {
      tr: 'Maddi Durum',
      en: 'Finances & Wealth',
    },
    categorySlug: 'finance',
    domainName: {
      tr: 'Gelir ve Finansal Güvenlik',
      en: 'Financial Security & Cash Flow',
    },
    question: {
      tr: 'Gelir ve Gider durumunuz nasıl ?',
      en: 'How is your income and expenditure balance?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Gelirim yeterli',
          en: 'My income is sufficient.',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Gelirim, giderlerimi karşılamıyor.',
          en: 'My income does not cover my expenses.',
        },
      },
    ],
    positiveAnswer: 'a',
    positiveLabel: {
      tr: 'Gelirim yeterli',
      en: 'Income is sufficient',
    },
    significance: {
      tr: 'Finansal güvenlik; temel ihtiyaçları huzurla karşılamanın ve geleceğe güvenle bakmanın temel şartıdır.',
      en: 'Financial baseline security guarantees peace of mind and resilience against life emergencies.',
    },
    recommendation: {
      title: {
        tr: 'Bütçe Farkındalığı & Finansal Acil Durum Fonu',
        en: 'Cash Flow Audit & Emergency Reserve',
      },
      advice: {
        tr: 'Maddi açık sürekli stres kaynağıdır. Harcamaları denetlemek ve mikro tasarrufla acil durum fonu kurmak ilk adımdır.',
        en: 'Financial deficits induce acute chronic anxiety. Auditing subscriptions and building an initial emergency cushion restores agency.',
      },
      actionSteps: {
        tr: [
          'Son 30 günün tüm harcamalarını listeleyerek farkında olmadan yapılan mikro sızıntıları kesin.',
          'Miktarı ne olursa olsun her gelirde %5-10 otomatik acil durum birikimi başlatın.',
          'Kredi kartı, ihtiyaç kredisi ve diğer borçları faiz/maliyet açısından listeleyin. Ekstra ödeme yapılacaksa maliyeti yüksek borçlara öncelik vermeyi değerlendirin.',
          'Zorunlu olmayan belirli bir tutarın üzerindeki alışverişleri hemen yapmayın.',
          'Kira, abonelikler, internet, telefon, sigorta, üyelikler ve benzeri düzenli ödemeleri tek tek kontrol edin. Kullanılmayan veya gereğinden pahalı olanları azaltın.',
          'Becerilerinizi değerlendirip ek gelir getirebilecek serbest çalışma modellerini araştırın.',
          'Not: Varlıklarınızı arttırmak için; Finans ve Ekonomi \' yi kolayca https://btankut.blogspot.com/2026/09/strategic-leadership-development.html Bloğunu takip ederek öğrenebilirsiniz.',
        ],
        en: [
          'Audit the last 30 days of expenses to immediately eliminate forgotten subscriptions and hidden leaks.',
          'Automate an untouchable 5-10% emergency savings transfer on every income receipt.',
          'List credit cards, consumer loans, and other debts by interest/cost. Consider prioritizing high-cost debts when making extra payments.',
          'Delay non-essential purchases above a set threshold; avoid immediate impulse buying.',
          'Review recurring expenses individually: rent, subscriptions, internet, phone, insurance, memberships, and similar payments. Reduce or eliminate unused or overpriced ones.',
          'Explore scalable side-skills or freelance avenues to generate a secondary cash stream.',
          'Note: To grow your wealth, you can easily learn Finance & Economics by following the blog at https://btankut.blogspot.com/2026/09/strategic-leadership-development.html',
        ],
      },
      impactRating: 5,
      timeToSeeChange: {
        tr: '1 - 2 Ay',
        en: '1 - 2 Months',
      },
    },
  },
  {
    id: 8,
    category: {
      tr: 'Kişisel Zaman & Hobi',
      en: 'Leisure & Hobbies',
    },
    categorySlug: 'leisure',
    domainName: {
      tr: 'Hobiler ve Serbest Zaman',
      en: 'Creative Recreation & Hobbies',
    },
    question: {
      tr: 'Hobilerim var / veya zamanımı güzel geçiriyorum?',
      en: 'Do you have hobbies / spend your leisure time pleasantly?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Evet',
          en: 'Yes',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Hayır',
          en: 'No',
        },
      },
    ],
    positiveAnswer: 'a',
    positiveLabel: {
      tr: 'Evet (Hobilerim var / zamanım güzel geçiyor)',
      en: 'Yes (Have hobbies & pleasant time)',
    },
    significance: {
      tr: 'Sadece zorunluluklar için değil, kendi saf zevkiniz için bir şeylerle meşgul olmak ruhu canlandırır.',
      en: 'Pursuing creative engagement purely for enjoyment invigorates the dopamine reward system.',
    },
    recommendation: {
      title: {
        tr: 'Ekran Bağımlılığından Yaratıcı Üretime Geçiş',
        en: 'From Passive Screen Time to Creative Flow',
      },
      advice: {
        tr: 'Boş zamanı pasif sosyal medya tüketimi yerine aktif bir hobiye ayırmak yaşam enerjisini katlar.',
        en: 'Shifting passive doom-scrolling toward tactile, tangible crafts revitalizes psychological well-being.',
      },
      actionSteps: {
        tr: [
          'Haftalık takviminize iptal edilemez 2 saatlik "Kişisel Hobi Randevusu" sabitleyin.',
          'Enstrüman, resim, ahşap, yemek pişirme, bahçe gibi ellerinizi kullandıran bir uğraş seçin.',
          'Hobi esnasında telefon bildirimlerini tamamen kapatın.',
        ],
        en: [
          'Block out a non-negotiable 2-hour "Personal Hobby Appointment" every weekend.',
          'Choose a tactile craft such as acoustic music, painting, gardening, baking, or carpentry.',
          'Switch your phone to Do Not Disturb to enter deep creative flow.',
        ],
      },
      impactRating: 4,
      timeToSeeChange: {
        tr: '1 Hafta',
        en: '1 Week',
      },
    },
  },
  {
    id: 9,
    category: {
      tr: 'Manevi Yaşam',
      en: 'Spiritual Peace',
    },
    categorySlug: 'spiritual',
    domainName: {
      tr: 'İçsel Huzur ve Manevi Değerler',
      en: 'Inner Stillness & Sacred Practice',
    },
    question: {
      tr: 'İbadetinizi yerine getirmeye çalışıyor musunuz ?',
      en: 'Do you make an effort to perform your worship or spiritual practices?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Bazen yapmaya çalışıyorum.',
          en: 'I try to practice them when possible.',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Zamanım yok, yapamıyorum.',
          en: 'I have no time; I cannot do them.',
        },
      },
    ],
    positiveAnswer: 'a',
    positiveLabel: {
      tr: 'Bazen yapmaya çalışıyorum (Manevi gayret)',
      en: 'I try to practice (Spiritual effort)',
    },
    significance: {
      tr: 'Maneviyat ve içsel tefekkür, insanın varoluşsal anlam bulmasına ve zihinsel sakinliğe erişmesine yardımcı olur.',
      en: 'Spiritual grounding and quiet contemplation provide existential anchoring and mental tranquility.',
    },
    recommendation: {
      title: {
        tr: 'Günlük Duraklama & İçsel Sükunet',
        en: 'Daily Sacred Pauses & Grounding',
      },
      advice: {
        tr: 'İbadet ve tefekkür için gün içinde "zamanım yok" illüzyonunu kıracak 5-10 dakikalık bilinçli molalar zihni arındırır.',
        en: 'Breaking the "no time" illusion through 5-10 minute mindful sacred pauses dissolves anxious rush.',
      },
      actionSteps: {
        tr: [
          'Belirli günlerde sessiz dua/kutsal metin okuma / tefekkür molası ayırın.',
          'Her akşam yatağa girmeden önce gün içinde şükrettiğiniz 3 şeyi zihninizden geçirin.',
          'Telaşlı anlarda 3 derin diyafram nefesi alarak manevi merkezine geri dönün.',
        ],
        en: [
          'Set aside dedicated times for silent prayer, reading sacred texts, or reflective contemplation.',
          'Review 3 genuine blessings before falling asleep to cultivate profound gratitude.',
          'Use 3 deep diaphragmatic breaths during hectic moments to re-center in the present moment.',
        ],
      },
      impactRating: 4,
      timeToSeeChange: {
        tr: 'Birkaç Gün',
        en: 'A Few Days',
      },
    },
  },
  {
    id: 10,
    category: {
      tr: 'Dinlenme & Tatil',
      en: 'Vacation & Rest',
    },
    categorySlug: 'vacation',
    domainName: {
      tr: 'Yıllık Yenilenme ve Seyahat',
      en: 'Annual Renewal & Travel',
    },
    question: {
      tr: 'Her sene tatil yapıyor musunuz ?',
      en: 'Do you take a vacation every year?',
    },
    options: [
      {
        key: 'a',
        label: {
          tr: 'Evet',
          en: 'Yes',
        },
      },
      {
        key: 'b',
        label: {
          tr: 'Hayır',
          en: 'No',
        },
      },
    ],
    positiveAnswer: 'a',
    positiveLabel: {
      tr: 'Evet (Her sene tatil yapıyorum)',
      en: 'Yes (Take an annual vacation)',
    },
    significance: {
      tr: 'Rutin çevreden uzaklaşmak, zihni sıfırlamak ve yeni yerler deneyimlemek psikolojik yenilenmenin olmazsa olmazıdır.',
      en: 'Stepping outside your habitual geography resets cognitive fatigue and unlocks creative perspective.',
    },
    recommendation: {
      title: {
        tr: 'Yenilenme Seyahati & Mikro Kaçamaklar',
        en: 'Rejuvenation Travel & Micro-Getaways',
      },
      advice: {
        tr: 'Tatil lüks otellere bağlı olmak zorunda değildir; doğada, sakin bir kasabada ya da farklı bir çevrede bulunmak yeterlidir.',
        en: 'Vacations need not be exorbitant; pitching a tent, exploring nearby nature, or changing scenery delivers identical renewal.',
      },
      actionSteps: {
        tr: [
          'Yıllık tatil için her ay küçük miktar para bir kenara ayırma alışkanlığı başlatın.',
          'Yılda bir uzun tatil yerine 2-3 ayda bir hafta sonu doğa ve çevre değişimi kaçamakları planlayın.',
          'Tatil süresince iş e-postalarını ve bildirimleri sessize alın.',
        ],
        en: [
          'Start a habit of setting aside a small amount of money each month for your annual vacation.',
          'Interleave your year with mini-weekend nature getaways every 2-3 months.',
          'Completely silence professional inboxes during away periods to guarantee genuine psychological detachment.',
        ],
      },
      impactRating: 4,
      timeToSeeChange: {
        tr: 'Planlandıktan Hemen Sonra',
        en: 'Immediately Upon Planning',
      },
    },
  },
];

export const ANSWER_KEY_SUMMARY = [
  { questionId: 1, key: 'a', textTr: 'Sağlık sorunum yok.', textEn: 'No health problems.' },
  { questionId: 2, key: 'b', textTr: 'Evet (Oturduğum evden memnunum)', textEn: 'Yes (Satisfied with home)' },
  { questionId: 3, key: 'b', textTr: 'Evet (Eğitimim yeterli)', textEn: 'Yes (Education is sufficient)' },
  { questionId: 4, key: 'b', textTr: 'Evet (İşimden memnunum)', textEn: 'Yes (Satisfied with job)' },
  { questionId: 5, key: 'a', textTr: 'Evet (Eşim/sevgilim var)', textEn: 'Yes (Have a partner)' },
  { questionId: 6, key: 'a', textTr: 'Evet (Arkadaş çevremden memnunum)', textEn: 'Yes (Satisfied with friends)' },
  { questionId: 7, key: 'a', textTr: 'Gelirim yeterli', textEn: 'Income is sufficient' },
  { questionId: 8, key: 'a', textTr: 'Evet (Hobilerim var)', textEn: 'Yes (Have hobbies)' },
  { questionId: 9, key: 'a', textTr: 'Bazen yapmaya çalışıyorum.', textEn: 'I try to practice.' },
  { questionId: 10, key: 'a', textTr: 'Evet (Her sene tatil yapıyorum)', textEn: 'Yes (Annual vacation)' },
];

export function calculateScore(answers: Record<number, 'a' | 'b'>): number {
  let score = 0;
  for (const q of QUESTIONS) {
    if (answers[q.id] === q.positiveAnswer) {
      score += 1;
    }
  }
  return score;
}

export function getScoreTier(score: number): ScoreTier {
  if (score <= 3) return SCORE_TIERS[0];
  if (score <= 5) return SCORE_TIERS[1];
  if (score <= 7) return SCORE_TIERS[2];
  return SCORE_TIERS[3];
}

export interface SimulationPreset {
  id: string;
  name: {
    tr: string;
    en: string;
  };
  description: {
    tr: string;
    en: string;
  };
  values: Record<number, 'a' | 'b'>;
}

export const SIMULATION_PRESETS: SimulationPreset[] = [
  {
    id: 'ideal_balance',
    name: {
      tr: 'İdeal Yaşam Dengesi (10/10)',
      en: 'Optimal Life Harmony (10/10)',
    },
    description: {
      tr: 'Tüm 10 alanda dengeli, huzurlu ve tatminkar standart.',
      en: 'Balanced, fulfilled, and vital conditions across all 10 life domains.',
    },
    values: {
      1: 'a', 2: 'b', 3: 'b', 4: 'b', 5: 'a',
      6: 'a', 7: 'a', 8: 'a', 9: 'a', 10: 'a',
    },
  },
  {
    id: 'career_workaholic',
    name: {
      tr: 'Kariyer & Maddiyat Odaklı (Tükenmişlik Riski)',
      en: 'Career & Work-Centric (Burnout Risk)',
    },
    description: {
      tr: 'İş ve para var ancak hobi, tatil, sağlık ve maneviyat kısıtlı (4-5 Puan).',
      en: 'Strong financial and work status, but suffering in health, vacation, hobbies, and peace.',
    },
    values: {
      1: 'b', 2: 'b', 3: 'b', 4: 'b', 5: 'b',
      6: 'b', 7: 'a', 8: 'b', 9: 'b', 10: 'b',
    },
  },
  {
    id: 'social_family',
    name: {
      tr: 'Sosyal & Aile Zengini (Ekonomik Baskı)',
      en: 'Rich Social & Family (Economic Strain)',
    },
    description: {
      tr: 'Sevgi, dostluk ve maneviyat güçlü; gelir ve ev koşullarında zorlanma (6-7 Puan).',
      en: 'Abundant affection and friendship, but experiencing financial and housing constraints.',
    },
    values: {
      1: 'a', 2: 'a', 3: 'a', 4: 'b', 5: 'a',
      6: 'a', 7: 'b', 8: 'a', 9: 'a', 10: 'b',
    },
  },
  {
    id: 'low_vitality',
    name: {
      tr: 'Kriz & Yeniden Başlangıç Durumu',
      en: 'Crisis & Fresh Start Condition',
    },
    description: {
      tr: 'Birden çok temel alanda eksiklik (1-2 Puan). Acil mikro adımlar gerekiyor.',
      en: 'Severe deficits across health, finance, and living spaces. Requires emergency micro-steps.',
    },
    values: {
      1: 'b', 2: 'a', 3: 'a', 4: 'a', 5: 'b',
      6: 'b', 7: 'b', 8: 'b', 9: 'b', 10: 'b',
    },
  },
];
