// Web Speech API Voice Utility

export interface SpeechOptions {
  lang: 'tr' | 'en';
  rate?: number;
  pitch?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: unknown) => void;
}

class SpeechManager {
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSpeaking = false;
  private isEnabled = true;
  private listeners: Set<(speaking: boolean, text: string) => void> = new Set();
  private currentText = '';

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = () => {
        // Voices loaded
      };
    }
  }

  public isSupported(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }

  public setEnabled(enabled: boolean) {
    this.isEnabled = enabled;
    if (!enabled) {
      this.stop();
    }
  }

  public getEnabled(): boolean {
    return this.isEnabled;
  }

  public subscribe(callback: (speaking: boolean, text: string) => void) {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notify(speaking: boolean, text: string) {
    this.isSpeaking = speaking;
    this.currentText = speaking ? text : '';
    this.listeners.forEach((listener) => {
      try {
        listener(speaking, this.currentText);
      } catch {
        // ignore listener errors
      }
    });
  }

  public speak(text: string, options: SpeechOptions) {
    if (!this.isSupported() || !this.isEnabled) {
      this.stop();
      if (!this.isSupported()) {
        options.onError?.(new Error('Speech Synthesis not supported in this browser.'));
      }
      return;
    }

    // Stop current speech first
    this.stop();

    if (!text || !text.trim() || !this.isEnabled) return;

    try {
      const utterance = new SpeechSynthesisUtterance(text);
      this.currentUtterance = utterance;

      const targetLang = options.lang === 'tr' ? 'tr-TR' : 'en-US';
      utterance.lang = targetLang;
      utterance.rate = options.rate ?? (options.lang === 'tr' ? 1.0 : 0.95);
      utterance.pitch = options.pitch ?? 1.0;

      // Select appropriate voice if available
      const voices = window.speechSynthesis.getVoices();
      const matchedVoice = voices.find(
        (v) => v.lang === targetLang || v.lang.startsWith(options.lang)
      );
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      utterance.onstart = () => {
        if (!this.isEnabled) {
          this.stop();
          return;
        }
        this.notify(true, text);
        options.onStart?.();
      };

      utterance.onend = () => {
        this.isSpeaking = false;
        this.currentText = '';
        this.notify(false, '');
        this.currentUtterance = null;
        options.onEnd?.();
      };

      utterance.onerror = (e) => {
        this.isSpeaking = false;
        this.currentText = '';
        this.notify(false, '');
        this.currentUtterance = null;
        options.onError?.(e);
      };

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      this.isSpeaking = false;
      this.currentText = '';
      this.notify(false, '');
      this.currentUtterance = null;
      options.onError?.(err);
    }
  }

  public stop() {
    if (this.isSupported()) {
      try {
        if (window.speechSynthesis.speaking || window.speechSynthesis.pending) {
          window.speechSynthesis.pause();
        }
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
      this.isSpeaking = false;
      this.currentText = '';
      this.currentUtterance = null;
      this.notify(false, '');
    }
  }

  public getStatus() {
    return {
      isSpeaking: this.isSpeaking,
      currentText: this.currentText,
    };
  }
}

export const speechManager = new SpeechManager();
