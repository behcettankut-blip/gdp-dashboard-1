import React, { useState, useEffect } from 'react';
import { QUESTIONS, Language } from './data/quizData';
import { UI_TRANSLATIONS } from './data/translations';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { StepQuiz } from './components/StepQuiz';
import { ListQuiz } from './components/ListQuiz';
import { ResultsView } from './components/ResultsView';
import { MethodologyModal } from './components/MethodologyModal';
import { LifeDimensionsGuide } from './components/LifeDimensionsGuide';
import { HyggeModal } from './components/HyggeModal';
import { ResetConfirmModal } from './components/ResetConfirmModal';
import { Footer } from './components/Footer';
import { speechManager } from './utils/speech';
import { soundFX } from './utils/audioEffects';

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    try {
      const savedLang = localStorage.getItem('yasam_kalitesi_lang');
      if (savedLang === 'en' || savedLang === 'tr') return savedLang;
      // Check browser language
      if (typeof navigator !== 'undefined' && navigator.language?.startsWith('en')) {
        return 'en';
      }
      return 'tr';
    } catch {
      return 'tr';
    }
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('yasam_kalitesi_sound');
      return saved !== 'false';
    } catch {
      return true;
    }
  });

  const [answers, setAnswers] = useState<Record<number, 'a' | 'b'>>(() => {
    try {
      const saved = localStorage.getItem('yasam_kalitesi_answers');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [quizMode, setQuizMode] = useState<'step' | 'list'>('step');
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(() => {
    try {
      const savedStatus = localStorage.getItem('yasam_kalitesi_completed');
      return savedStatus === 'true';
    } catch {
      return false;
    }
  });

  const [activeSection, setActiveSection] = useState<'quiz' | 'scoring' | 'dimensions'>('quiz');
  const [isMethodologyOpen, setIsMethodologyOpen] = useState(false);
  const [isHyggeOpen, setIsHyggeOpen] = useState(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);

  // Sync sound settings to managers
  useEffect(() => {
    soundFX.setEnabled(soundEnabled);
    speechManager.setEnabled(soundEnabled);
    if (!soundEnabled) {
      speechManager.stop();
      soundFX.stopAll();
    }
  }, [soundEnabled]);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem('yasam_kalitesi_answers', JSON.stringify(answers));
      localStorage.setItem('yasam_kalitesi_completed', String(isCompleted));
      localStorage.setItem('yasam_kalitesi_lang', lang);
      localStorage.setItem('yasam_kalitesi_sound', String(soundEnabled));
    } catch {
      // ignore
    }
  }, [answers, isCompleted, lang, soundEnabled]);

  // Clean up speech on section change or language switch
  useEffect(() => {
    speechManager.stop();
  }, [activeSection, lang]);

  const answeredCount = Object.keys(answers).length;

  const handleToggleSound = () => {
    setSoundEnabled((prev) => {
      const next = !prev;
      soundFX.setEnabled(next);
      speechManager.setEnabled(next);
      if (!next) {
        // Enforce immediate cancellation of all ongoing speech and sounds
        speechManager.stop();
        soundFX.stopAll();
      } else {
        soundFX.playNavClick();
      }
      return next;
    });
  };

  const handleToggleLang = () => {
    speechManager.stop();
    soundFX.playNavClick();
    setLang((prev) => {
      const nextLang = prev === 'tr' ? 'en' : 'tr';
      if (soundEnabled) {
        const promptText = nextLang === 'tr' ? 'Türkçe dili seçildi.' : 'English language selected.';
        speechManager.speak(promptText, { lang: nextLang });
      }
      return nextLang;
    });
  };

  const handleSelectAnswer = (questionId: number, optionKey: 'a' | 'b') => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: optionKey,
    }));

    if (quizMode === 'step' && currentStepIndex < QUESTIONS.length - 1) {
      setTimeout(() => {
        setCurrentStepIndex((prev) => Math.min(QUESTIONS.length - 1, prev + 1));
      }, 250);
    }
  };

  const handleResetRequest = () => {
    soundFX.playNavClick();
    setIsResetModalOpen(true);
  };

  const handleConfirmReset = () => {
    speechManager.stop();
    soundFX.playNavClick();
    setAnswers({});
    setIsCompleted(false);
    setCurrentStepIndex(0);
    setActiveSection('quiz');
    try {
      localStorage.removeItem('yasam_kalitesi_answers');
      localStorage.removeItem('yasam_kalitesi_completed');
    } catch {
      // ignore
    }
    if (soundEnabled) {
      const resetMsg =
        lang === 'tr'
          ? 'Test sıfırlandı. 1. sorudan başlayabilirsiniz.'
          : 'Assessment reset. You can begin from question 1.';
      speechManager.speak(resetMsg, { lang });
    }
  };

  const handleStartQuiz = (mode: 'step' | 'list') => {
    soundFX.playNavClick();
    setQuizMode(mode);
    setActiveSection('quiz');
    setIsCompleted(false);
  };

  const handleComplete = () => {
    speechManager.stop();
    setIsCompleted(true);
    setActiveSection('quiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigate = (section: 'quiz' | 'scoring' | 'dimensions') => {
    speechManager.stop();
    soundFX.playNavClick();
    if (section === 'scoring') {
      setIsMethodologyOpen(true);
      return;
    }
    setActiveSection(section);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenHygge = () => {
    soundFX.playNavClick();
    setIsHyggeOpen(true);
  };

  const t = UI_TRANSLATIONS[lang];

  return (
    <div className="min-h-screen flex flex-col bg-stone-100/80 text-stone-900 font-sans">
      <Header
        onNavigate={handleNavigate}
        onOpenHygge={handleOpenHygge}
        activeSection={activeSection}
        onReset={handleResetRequest}
        isCompleted={isCompleted}
        answeredCount={answeredCount}
        lang={lang}
        onToggleLang={handleToggleLang}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
      />

      <main className="flex-1 max-w-5xl w-full mx-auto px-3 sm:px-6 py-6 sm:py-10">
        {/* Prominent Dark Frame Container for the Simulation */}
        <div className="rounded-2xl sm:rounded-3xl border-2 sm:border-[3px] border-stone-900 bg-white shadow-2xl overflow-hidden ring-1 ring-stone-950/20">
          {/* Dark Frame Top Accent Bar */}
          <div className="bg-stone-900 text-stone-200 px-4 sm:px-6 py-3 border-b-2 border-stone-800 flex flex-wrap items-center justify-between gap-3 select-none">
            <div className="flex items-center gap-2.5">
              <div className="flex gap-1.5" aria-hidden="true">
                <span className="w-3 h-3 rounded-full bg-rose-500 inline-block shadow-xs" />
                <span className="w-3 h-3 rounded-full bg-amber-500 inline-block shadow-xs" />
                <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block shadow-xs" />
              </div>
              <span className="font-extrabold text-xs sm:text-sm text-white tracking-wide uppercase">
                {lang === 'tr' ? 'Yaşam Kalitesi Simülasyonu & Değerlendirme' : 'Life Quality Simulation & Assessment'}
              </span>
            </div>

            <div className="flex items-center gap-2.5 text-xs">
              {/* Frame Quick Audio Control */}
              <button
                type="button"
                onClick={handleToggleSound}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                  soundEnabled
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/80 hover:bg-emerald-900 shadow-xs'
                    : 'bg-stone-800 text-stone-400 border border-stone-700 hover:bg-stone-750'
                }`}
                title={soundEnabled ? (lang === 'tr' ? 'Sesi Kapat (Durdur)' : 'Mute Sound') : (lang === 'tr' ? 'Sesi Aç' : 'Enable Sound')}
              >
                {soundEnabled ? (
                  <>
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse inline-block" />
                    <span>{lang === 'tr' ? 'Ses Açık' : 'Sound ON'}</span>
                  </>
                ) : (
                  <>
                    <span className="w-2 h-2 rounded-full bg-stone-500 inline-block" />
                    <span>{lang === 'tr' ? 'Ses Kapalı' : 'Sound Muted'}</span>
                  </>
                )}
              </button>

              <span className="text-stone-400 font-mono text-[11px] hidden sm:inline border-l border-stone-800 pl-2.5">
                {lang === 'tr' ? '10/10 Standart' : '10/10 Benchmark'}
              </span>
            </div>
          </div>

          {/* Simulation inner viewport */}
          <div className="p-4 sm:p-8 bg-stone-50/40">
            {activeSection === 'dimensions' ? (
              <LifeDimensionsGuide
                onStartQuiz={() => handleStartQuiz('step')}
                lang={lang}
              />
            ) : isCompleted ? (
              <ResultsView
                questions={QUESTIONS}
                answers={answers}
                lang={lang}
                onReset={handleResetRequest}
                onOpenMethodology={() => setIsMethodologyOpen(true)}
              />
            ) : (
              <div>
                {/* Show hero banner if user hasn't answered yet */}
                {answeredCount === 0 && (
                  <HeroBanner
                    onStartQuiz={handleStartQuiz}
                    answeredCount={answeredCount}
                    lang={lang}
                  />
                )}

                {/* Quiz Mode Selector if already started */}
                {answeredCount > 0 && (
                  <div className="max-w-3xl mx-auto mb-6 flex items-center justify-between border-b border-stone-200 pb-3">
                    <div className="flex items-center gap-2 text-xs font-semibold text-stone-700">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span>
                        {t.quiz.ongoing.replace('{count}', String(answeredCount))}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 bg-stone-200/70 p-1 rounded-lg text-xs font-medium">
                      <button
                        onClick={() => setQuizMode('step')}
                        className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                          quizMode === 'step'
                            ? 'bg-white text-stone-900 font-bold shadow-xs'
                            : 'text-stone-600 hover:text-stone-900'
                        }`}
                      >
                        {lang === 'tr' ? 'Adım Adım' : 'Step-by-Step'}
                      </button>
                      <button
                        onClick={() => setQuizMode('list')}
                        className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                          quizMode === 'list'
                            ? 'bg-white text-stone-900 font-bold shadow-xs'
                            : 'text-stone-600 hover:text-stone-900'
                        }`}
                      >
                        {lang === 'tr' ? 'Tüm Liste' : 'Full List'}
                      </button>
                    </div>
                  </div>
                )}

                {/* Active Quiz View */}
                {quizMode === 'step' ? (
                  <StepQuiz
                    questions={QUESTIONS}
                    currentIndex={currentStepIndex}
                    answers={answers}
                    lang={lang}
                    onSelectAnswer={handleSelectAnswer}
                    onPrev={() => setCurrentStepIndex((p) => Math.max(0, p - 1))}
                    onNext={() =>
                      setCurrentStepIndex((p) => Math.min(QUESTIONS.length - 1, p + 1))
                    }
                    onJumpTo={(idx) => setCurrentStepIndex(idx)}
                    onComplete={handleComplete}
                    onSwitchMode={() => setQuizMode('list')}
                  />
                ) : (
                  <ListQuiz
                    questions={QUESTIONS}
                    answers={answers}
                    lang={lang}
                    onSelectAnswer={handleSelectAnswer}
                    onComplete={handleComplete}
                    onSwitchMode={() => setQuizMode('step')}
                  />
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer
        onNavigate={handleNavigate}
        onOpenMethodology={() => setIsMethodologyOpen(true)}
        onOpenHygge={handleOpenHygge}
        lang={lang}
      />

      <MethodologyModal
        isOpen={isMethodologyOpen}
        onClose={() => setIsMethodologyOpen(false)}
        lang={lang}
      />

      <HyggeModal
        isOpen={isHyggeOpen}
        onClose={() => setIsHyggeOpen(false)}
        lang={lang}
      />

      <ResetConfirmModal
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        onConfirm={handleConfirmReset}
        lang={lang}
      />
    </div>
  );
}
